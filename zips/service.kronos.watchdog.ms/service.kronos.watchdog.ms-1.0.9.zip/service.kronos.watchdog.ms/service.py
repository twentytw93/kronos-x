#twentytw93-KronosTeam

import xbmc
import time

# Delay after boot/login to avoid interference
xbmc.log("[KronosMSWatchdog] Boot detected. Waiting 30 seconds before initialization...", xbmc.LOGINFO)
xbmc.sleep(30000)  # 30 seconds delay

class KronosMSWatchdog(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = xbmc.Player()
        
        # Track service start time for minimum runtime check
        self.start_time = time.time()
        self.minimum_runtime = 10  # Don't shutdown in first 10 seconds
        
        # Blocked addons (lowercase for case-insensitive matching)
        self.blocked_addons = {
            "plugin.video.seren",
            "plugin.video.cumination",
            "plugin.video.watchnixtoons2",
            "plugin.video.otaku",
            "plugin.video.youtube",
            "plugin.video.elementum",
            "plugin.program.kronos.shield",
            "plugin.program.kronos.mane",
            "plugin.program.kronos.cast",
            "plugin.program.kronos.pulse",
            "plugin.video.retrospect"
        }
        self.enemy_audio_addon = "plugin.audio.soundcloud"
        
        # State variables (no locks needed - Kodi is single-threaded)
        self.has_paused = False
        self.was_in_blocked_addon = False
        self.pause_start_time = None
        self.pause_timeout = 540  # 9 minutes
        self.has_paused_for_playlist = False
        
        # Simple cache for reducing API calls
        self.cache_plugin = ""
        self.cache_path = ""
        self.cache_time = 0
        self.cache_duration = 0.3  # 300ms cache
        
        # Error handling with exponential backoff
        self.error_count = 0
        self.max_errors = 5
        self.error_backoff = 1.0
        self.max_backoff = 30.0
        self.degraded_mode = False
        
        # Notification cooldown to prevent spam
        self.last_notification_time = 0
        self.notification_cooldown = 2.0  # 2 seconds between notifications
        self.last_notification_message = ""

    def show_notification(self, message, duration=3000, force=False):
        """Show notification with cooldown to prevent spam"""
        current_time = time.time()
        time_since_last = current_time - self.last_notification_time
        
        # Skip if same message within cooldown period (unless forced)
        if not force and message == self.last_notification_message and time_since_last < self.notification_cooldown:
            return
        
        try:
            xbmc.executebuiltin(f'Notification("[B]Kronos WatchDog[/B]", {message}, {duration})')
            self.last_notification_time = current_time
            self.last_notification_message = message
        except Exception as e:
            xbmc.log(f"[Kronos Watchdog-MS] Notification failed: {e}", xbmc.LOGDEBUG)

    def get_cached_info(self):
        """Get cached plugin and path info with simple error handling"""
        current_time = time.time()
        
        # Return cache if still valid
        if current_time - self.cache_time < self.cache_duration and self.cache_plugin is not None:
            return self.cache_plugin, self.cache_path
        
        # Refresh cache with error handling
        try:
            plugin = xbmc.getInfoLabel("Container.PluginName") or ""
            path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""
            
            # Normalize to lowercase for case-insensitive matching
            self.cache_plugin = plugin.lower()
            self.cache_path = path.lower()
            self.cache_time = current_time
            
            return self.cache_plugin, self.cache_path
            
        except Exception as e:
            # Use LOGDEBUG - this is frequent and usually recoverable
            xbmc.log(f"[Kronos Watchdog-MS] getInfoLabel failed: {e}", xbmc.LOGDEBUG)
            # Return last known values (may be stale, but better than crashing)
            return self.cache_plugin, self.cache_path

    def is_player_playing_audio(self):
        """Safe check if player is playing audio"""
        try:
            return self.player.isPlayingAudio()
        except Exception as e:
            # Use LOGDEBUG for frequent checks to reduce log noise
            xbmc.log(f"[Kronos Watchdog-MS] isPlayingAudio check failed: {e}", xbmc.LOGDEBUG)
            return False

    def reset_state(self):
        """Reset all state variables"""
        self.has_paused = False
        self.was_in_blocked_addon = False
        self.pause_start_time = None
        self.has_paused_for_playlist = False

    def handle_error(self):
        """Implement exponential backoff for errors"""
        self.error_count += 1
        
        if self.error_count >= self.max_errors and not self.degraded_mode:
            xbmc.log("[Kronos Watchdog-MS] Entering degraded mode due to repeated errors", xbmc.LOGWARNING)
            self.degraded_mode = True
        
        # Calculate backoff time with exponential increase
        backoff = min(self.error_backoff * (2 ** (self.error_count - 1)), self.max_backoff)
        xbmc.log(f"[Kronos Watchdog-MS] Error backoff: {backoff:.1f}s (error count: {self.error_count})", xbmc.LOGDEBUG)
        return backoff

    def reset_error_state(self):
        """Reset error counters after successful operation"""
        if self.error_count > 0:
            self.error_count = 0
            if self.degraded_mode:
                xbmc.log("[Kronos Watchdog-MS] Exiting degraded mode", xbmc.LOGINFO)
                self.degraded_mode = False

    def run(self):
        xbmc.log("[Kronos Watchdog-MS] Started", xbmc.LOGINFO)
        
        consecutive_inactive_checks = 0

        while not self.abortRequested():
            try:
                # Get current state with caching
                plugin, path = self.get_cached_info()
                is_ms_active = "plugin.audio.mp3streams" in path
                is_playing = self.is_player_playing_audio()
                
                # Check music OSD with error handling
                try:
                    in_music_osd = xbmc.getCondVisibility("Window.IsVisible(10120)")
                except:
                    in_music_osd = False
                
                # Reset error state on successful iteration
                self.reset_error_state()

                # === ADAPTIVE SLEEP: If MP3 Streams inactive, use progressively longer intervals ===
                if not is_ms_active:
                    consecutive_inactive_checks += 1
                    # Progressive backoff: 1s → 1.5s → 2s → 2.5s → ... → 5s (max)
                    sleep_time = min(1.0 + (consecutive_inactive_checks * 0.5), 5.0)
                    
                    # Check minimum runtime before allowing long sleeps
                    runtime = time.time() - self.start_time
                    if runtime < self.minimum_runtime:
                        sleep_time = min(sleep_time, 0.5)  # Keep responsive during startup
                    
                    self.waitForAbort(sleep_time)
                    continue
                else:
                    consecutive_inactive_checks = 0

                # === RULE 1: Kill MP3 Streams if SoundCloud launches ===
                if plugin == self.enemy_audio_addon and is_playing:
                    xbmc.log("[Kronos Watchdog-MS] SoundCloud launched. Stopping MP3 Streams.", xbmc.LOGINFO)
                    try:
                        self.player.stop()
                        xbmc.executebuiltin('ClearPlaylist(audio)')
                        self.show_notification("MP3 Streams Stopped")
                        self.reset_state()
                    except Exception as e:
                        xbmc.log(f"[Kronos Watchdog-MS] Stop failed: {e}", xbmc.LOGERROR)
                    self.waitForAbort(1.0)
                    continue

                # === RULE 2: Pause when playlist window opens ===
                if is_playing and in_music_osd and not self.has_paused_for_playlist:
                    xbmc.log("[Kronos Watchdog-MS] Playlist opened. Pausing stream.", xbmc.LOGINFO)
                    try:
                        self.player.pause()
                        self.has_paused_for_playlist = True
                        self.show_notification("Paused for stability", 2000)
                    except Exception as e:
                        xbmc.log(f"[Kronos Watchdog-MS] Playlist pause failed: {e}", xbmc.LOGERROR)

                # === RULE 3: Reset playlist pause flag after closing ===
                elif self.has_paused_for_playlist and not in_music_osd:
                    xbmc.log("[Kronos Watchdog-MS] Playlist closed.", xbmc.LOGDEBUG)
                    self.has_paused_for_playlist = False

                # === RULE 4: Pause if blocked video add-on starts ===
                if plugin in self.blocked_addons and is_playing and not self.has_paused:
                    xbmc.log(f"[Kronos Watchdog-MS] {plugin} active. Pausing MP3 Streams.", xbmc.LOGINFO)
                    try:
                        self.player.pause()
                        self.has_paused = True
                        self.was_in_blocked_addon = True
                        self.pause_start_time = time.time()
                        self.show_notification("MP3 Streams Paused")
                    except Exception as e:
                        xbmc.log(f"[Kronos Watchdog-MS] Pause failed: {e}", xbmc.LOGERROR)

                # === RULE 5: Resume if user returns home from blocked add-on ===
                elif plugin == '' and self.has_paused and self.was_in_blocked_addon:
                    xbmc.log("[Kronos Watchdog-MS] Home detected. Resuming MP3 Streams.", xbmc.LOGINFO)
                    try:
                        self.player.pause()  # Toggle pause to resume
                        self.has_paused = False
                        self.was_in_blocked_addon = False
                        self.pause_start_time = None
                        self.show_notification("MP3 Streams Resumed", 2000)
                    except Exception as e:
                        xbmc.log(f"[Kronos Watchdog-MS] Resume failed: {e}", xbmc.LOGERROR)

                # === RULE 6: Stop if paused too long ===
                elif self.has_paused and self.pause_start_time:
                    elapsed = time.time() - self.pause_start_time
                    if elapsed >= self.pause_timeout:
                        xbmc.log("[Kronos Watchdog-MS] MP3 paused too long. Stopping.", xbmc.LOGINFO)
                        try:
                            self.player.stop()
                            xbmc.executebuiltin('ClearPlaylist(audio)')
                            self.show_notification("MP3 Streams Closed")
                        except Exception as e:
                            xbmc.log(f"[Kronos Watchdog-MS] Timeout stop failed: {e}", xbmc.LOGERROR)
                        self.reset_state()

                # Normal polling when MP3Streams is active
                self.waitForAbort(0.5)

            except Exception as e:
                xbmc.log(f"[Kronos Watchdog-MS] CRITICAL ERROR: {e}", xbmc.LOGERROR)
                
                # Reset state to prevent stuck flags
                self.reset_state()
                
                # Calculate backoff time and wait
                backoff_time = self.handle_error()
                self.waitForAbort(backoff_time)

        xbmc.log("[Kronos Watchdog-MS] Shutdown signal received.", xbmc.LOGINFO)

if __name__ == "__main__":
    KronosMSWatchdog().run()
