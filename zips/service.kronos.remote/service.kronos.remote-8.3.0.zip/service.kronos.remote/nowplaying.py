# -*- coding: utf-8 -*-
# nowplaying.py - Kronos Remote LAN
# v1.1.1
#
# Behavior:
#   - PVR / IPTV Simple (pvr://...) => FORCED "TV Stream" (no timestamps) + seekbar disabled
#   - Everything else => title only for video (NO timestamps), music stays clean
#   - Exposes:
#       get_nowplaying_string(lock=None) -> str
#       get_status(lock=None) -> dict          (for /status seekbar)
#       get_playback_status(lock=None) -> dict (alias)
#
# IMPORTANT:
# - lock is optional and may already be held by caller (service.py /status).
# - We ONLY try a NON-BLOCKING acquire to avoid deadlocks.

from __future__ import annotations

import json
import xbmc


def _try_acquire(lock) -> bool:
    if not lock:
        return False
    try:
        return bool(lock.acquire(False))  # non-blocking
    except Exception:
        return False


def _safe_release(lock):
    try:
        lock.release()
    except Exception:
        pass


def _jsonrpc(method: str, params: dict | None = None) -> dict:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        data = json.loads(raw) if raw else {}
    except Exception:
        data = {}
    return data if isinstance(data, dict) else {}


def _hms_to_seconds(t: dict) -> int:
    try:
        h = int(t.get("hours", 0) or 0)
        m = int(t.get("minutes", 0) or 0)
        s = int(t.get("seconds", 0) or 0)
        return (h * 3600) + (m * 60) + s
    except Exception:
        return 0


def _get_active_player() -> tuple[int | None, str]:
    try:
        r = _jsonrpc("Player.GetActivePlayers")
        lst = r.get("result") or []
        if not isinstance(lst, list) or not lst:
            return None, ""
        first = lst[0] if isinstance(lst[0], dict) else {}
        pid = first.get("playerid", None)
        ptype = first.get("type", "") or ""
        try:
            pid = int(pid)
        except Exception:
            pid = None
        return pid, ptype
    except Exception:
        return None, ""


def get_nowplaying_string(lock=None) -> str:
    acquired = _try_acquire(lock)
    try:
        player = xbmc.Player()

        # No playback
        if not (player.isPlayingVideo() or player.isPlayingAudio()):
            return "idle"

        path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""

        # PVR / IPTV Simple: FORCE label
        if path.startswith("pvr://"):
            return "TV Stream"

        # Music (keep clean)
        if player.isPlayingAudio() and not player.isPlayingVideo():
            artist = (xbmc.getInfoLabel("MusicPlayer.Artist") or "").strip()
            title = (xbmc.getInfoLabel("MusicPlayer.Title") or "").strip()
            if artist and title:
                return f"{artist} - {title}"
            return title or artist or "Music"

        # Video (non-PVR): title ONLY (NO timestamps)
        show = (xbmc.getInfoLabel("VideoPlayer.TVShowTitle") or "").strip()
        season = (xbmc.getInfoLabel("VideoPlayer.Season") or "").strip()
        episode = (xbmc.getInfoLabel("VideoPlayer.Episode") or "").strip()

        base_title = ""

        if show:
            se = ""
            if season.isdigit() and episode.isdigit():
                se = f" S{int(season):02d}E{int(episode):02d}"
            base_title = f"{show}{se}".strip()
        else:
            base_title = (
                (xbmc.getInfoLabel("Player.Title") or "").strip()
                or (xbmc.getInfoLabel("VideoPlayer.Title") or "").strip()
                or (xbmc.getInfoLabel("Player.Filename") or "").strip()
            )

        if not base_title:
            base_title = "Video"

        return base_title

    except Exception:
        return "idle"
    finally:
        if acquired:
            _safe_release(lock)


def get_status(lock=None) -> dict:
    """
    JSON payload for /status seekbar logic.

    Required keys used by interface:
      - ok, playing, type, is_pvr, seekable, time_sec, duration_sec, percent, label, show_seekbar
    """
    acquired = _try_acquire(lock)
    try:
        player = xbmc.Player()

        is_video = bool(player.isPlayingVideo())
        is_audio = bool(player.isPlayingAudio())
        playing = bool(is_video or is_audio)

        if not playing:
            return {
                "ok": True,
                "playing": False,
                "type": "",
                "path": "",
                "is_pvr": False,
                "seekable": False,
                "time_sec": 0,
                "duration_sec": 0,
                "percent": 0.0,
                "label": "idle",
                "show_seekbar": False,
            }

        path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""
        is_pvr = bool(path.startswith("pvr://"))

        # Default labels
        if is_pvr:
            label = "TV Stream"
        else:
            label = get_nowplaying_string(None)  # no lock attempt here

        # Pull accurate time/duration/percent from JSON-RPC
        pid, ptype = _get_active_player()
        time_sec = 0
        duration_sec = 0
        percent = 0.0

        if pid is not None:
            props = _jsonrpc(
                "Player.GetProperties",
                {
                    "playerid": pid,
                    "properties": ["time", "totaltime", "percentage", "speed"],
                },
            ).get("result") or {}

            if isinstance(props, dict):
                time_sec = _hms_to_seconds(props.get("time") or {})
                duration_sec = _hms_to_seconds(props.get("totaltime") or {})
                try:
                    percent = float(props.get("percentage", 0.0) or 0.0)
                except Exception:
                    percent = 0.0

        seekable = bool((not is_pvr) and duration_sec > 0)

        return {
            "ok": True,
            "playing": True,
            "type": ptype or ("video" if is_video else ("audio" if is_audio else "")),
            "path": path,
            "is_pvr": is_pvr,
            "seekable": seekable,
            "time_sec": int(time_sec),
            "duration_sec": int(duration_sec),
            "percent": float(percent),
            "label": label,
            "show_seekbar": bool(seekable),
        }

    except Exception:
        return {
            "ok": False,
            "error": "status_failed",
        }
    finally:
        if acquired:
            _safe_release(lock)


def get_playback_status(lock=None) -> dict:
    # Alias for service.py compatibility (if it looks for this name)
    return get_status(lock)
