# -*- coding: utf-8 -*-
# Kronos Remote LAN – Kodi Actions
# v4.0.8 - PATCHED
#
# Fixes:
# - _seek_to_percent: Added defensive check for empty path string
# - Now checks: if not path or path.startswith("pvr://")
# - Added additional PVR detection via Player.GetItem for robustness
#
# Previous Changes:
# - Added support for long-press OK key: ok_long -> Action(ContextMenu)
# - Added support for shortcut keys via shortcuts.handle_shortcut()
# - Added support for: seek_percent:<0-100> (JSON-RPC Player.Seek)

from __future__ import annotations

import json
import threading
import xbmc

from player_elementum import play_movie_by_tmdb, open_tvshow_by_tmdb, play_tvshow_episode_by_tmdb
from subtitles import handle_subtitles
from shortcuts import handle_shortcut

_KODI_LOCK = threading.Lock()


def _extract_key(args) -> str:
    """
    Accepts:
      perform_kodi_action("up")
      perform_kodi_action(self, "up")
      perform_kodi_action(lock, "up")
    Returns first string/bytes argument found.
    """
    for a in args:
        if isinstance(a, str):
            return a.strip()
        if isinstance(a, (bytes, bytearray)):
            try:
                return a.decode("utf-8", errors="replace").strip()
            except Exception:
                return ""
    return ""


def _jsonrpc(method: str, params: dict | None = None) -> dict:
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params is not None:
            req["params"] = params
        raw = xbmc.executeJSONRPC(json.dumps(req))
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _get_active_player_id() -> int | None:
    data = _jsonrpc("Player.GetActivePlayers")
    players = data.get("result")
    if not isinstance(players, list) or not players:
        return None
    p0 = players[0]
    if not isinstance(p0, dict):
        return None
    pid = p0.get("playerid")
    try:
        return int(pid)
    except Exception:
        return None


def _is_pvr_stream() -> bool:
    """
    Enhanced PVR detection: check both path and player item type.
    FIXED: Now handles empty path string correctly.
    """
    try:
        # Check 1: FilenameAndPath
        path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""
        # FIXED: Check for empty string before startswith
        if not path:
            # Empty path - check via other methods
            pass
        elif path.startswith("pvr://"):
            return True
        
        # Check 2: Player.GetItem for additional robustness
        pid = _get_active_player_id()
        if pid is not None:
            data = _jsonrpc("Player.GetItem", {"playerid": pid, "properties": ["type"]})
            result = data.get("result", {})
            if isinstance(result, dict):
                item = result.get("item", {})
                if isinstance(item, dict):
                    item_type = item.get("type", "")
                    if item_type == "channel":
                        return True
        
        return False
    except Exception:
        # On error, assume not PVR (safer for seeking)
        return False


def _seek_to_percent(percent: float) -> bool:
    """
    FIXED: Now properly detects PVR streams even with empty path.
    """
    try:
        # FIXED: Enhanced PVR detection
        if _is_pvr_stream():
            return False

        pid = _get_active_player_id()
        if pid is None:
            return False

        # clamp
        if percent < 0.0:
            percent = 0.0
        if percent > 100.0:
            percent = 100.0

        # Try float percentage first, then fallback to int
        data = _jsonrpc("Player.Seek", {"playerid": pid, "value": {"percentage": float(percent)}})
        if "error" not in data:
            return True

        data = _jsonrpc("Player.Seek", {"playerid": pid, "value": int(round(percent))})
        return "error" not in data
    except Exception:
        return False


def perform_kodi_action(*args) -> bool:
    with _KODI_LOCK:
        key = _extract_key(args)
        if not key:
            return False

        low = key.lower()

        # ---- Subtitles (separate module) ----
        try:
            if handle_subtitles(low):
                return True
        except Exception:
            pass

        # ---- Shortcuts (Elementum / IPTV / WatchNixtoon2) ----
        try:
            if handle_shortcut(low):
                return True
        except Exception:
            pass

        # ---- Seek slider ----
        # seek_percent:<0-100>
        if low.startswith("seek_percent:"):
            try:
                val = key.split(":", 1)[1].strip()
                pct = float(val)
            except Exception:
                return False
            return _seek_to_percent(pct)

        # ---- Send text to Kodi's active input dialog ----
        # sendtext:<text>
        if low.startswith("sendtext:"):
            try:
                text = key.split(":", 1)[1]
                if not text:
                    return False
                _jsonrpc("Input.SendText", {"text": text, "done": True})
                return True
            except Exception:
                return False

        # ---- Play keys coming from HTML (/nav) ----
        # play_movie:<tmdb_id>
        # play_tv:<tmdb_id>
        # play_tv_ep:<tmdb_id>:<season>:<episode>
        if low.startswith("play_movie:"):
            try:
                tmdb_id = int(key.split(":", 1)[1].strip() or "0")
            except Exception:
                return False
            return play_movie_by_tmdb(tmdb_id)

        if low.startswith("play_tv:"):
            try:
                tmdb_id = int(key.split(":", 1)[1].strip() or "0")
            except Exception:
                return False
            return open_tvshow_by_tmdb(tmdb_id)

        if low.startswith("play_tv_ep:"):
            try:
                rest = key.split(":", 1)[1]
                parts = [p.strip() for p in rest.split(":")]
                tmdb_id = int(parts[0] or "0") if len(parts) >= 1 else 0
                season = int(parts[1] or "0") if len(parts) >= 2 else 0
                episode = int(parts[2] or "0") if len(parts) >= 3 else 0
            except Exception:
                return False
            return play_tvshow_episode_by_tmdb(tmdb_id, season, episode)

        # Home
        if low == "home":
            try:
                xbmc.executebuiltin("ActivateWindow(Home)")
                return True
            except Exception:
                return False

        mapping = {
            # Navigation
            "up": "Up",
            "down": "Down",
            "left": "Left",
            "right": "Right",
            "ok": "Select",
            "ok_long": "ContextMenu",
            "select": "Select",
            "enter": "Select",
            "back": "Back",

            # Playback
            "prev": "SkipPrevious",
            "rew": "Rewind",
            "playpause": "PlayPause",
            "fwd": "FastForward",
            "next": "SkipNext",
            "stop": "Stop",

            # OSD
            "osd": "Info",

            # Volume
            "volup": "VolumeUp",
            "voldown": "VolumeDown",
            "mute": "Mute",
        }

        action = mapping.get(low)
        if not action:
            return False

        try:
            xbmc.executebuiltin(f"Action({action})")
            return True
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Keyboard input helpers (called directly from service.py endpoints)
# ---------------------------------------------------------------------------

def keyboard_type_char(char: str) -> bool:
    """Send a single character to Kodi's active keyboard dialog."""
    with _KODI_LOCK:
        try:
            data = _jsonrpc("Input.SendText", {"text": char, "done": False})
            return "error" not in data
        except Exception:
            return False


def keyboard_backspace() -> bool:
    """Send backspace to Kodi's active keyboard dialog."""
    with _KODI_LOCK:
        try:
            xbmc.executebuiltin("Action(Backspace)")
            return True
        except Exception:
            return False


def keyboard_enter() -> bool:
    """Send enter/confirm to Kodi's active keyboard dialog."""
    with _KODI_LOCK:
        try:
            xbmc.executebuiltin("Action(Select)")
            return True
        except Exception:
            return False


def keyboard_clear() -> bool:
    """Clear the text in Kodi's active keyboard dialog."""
    with _KODI_LOCK:
        try:
            data = _jsonrpc("Input.SendText", {"text": "", "done": False})
            return "error" not in data
        except Exception:
            return False


def keyboard_send_text(text: str, done: bool = True) -> bool:
    """Send full text to Kodi's active keyboard dialog."""
    with _KODI_LOCK:
        try:
            data = _jsonrpc("Input.SendText", {"text": text, "done": done})
            return "error" not in data
        except Exception:
            return False
