# -*- coding: utf-8 -*-
# Kronos Remote LAN – Routes
# v4.0.4 - CLEANED
#
# Cleanup:
# - Removed redundant `import X as _xx; X = _xx` alias patterns across all 7
#   module imports (direct `import X` achieves the same with pre-declared None)
# - Combined split kodi_actions `from` imports into a single line
# - Fixed stale function references that would cause AttributeError at runtime:
#     tmdb.movies_trending() → tmdb.trending_movies()
#     tmdb.tv_trending()     → tmdb.trending_tv()
#     tmdb.search_movie()    → tmdb.search_movies()
#     tools.reboot()         → tools.restart()

from __future__ import annotations

import os
import json
from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
INTERFACE_HTML_PATH = os.path.join(ADDON_PATH, "resources", "interface.html")

# Import resilience: each module independently
kodi_actions = None
shortcuts = None
subtitles = None
nowplaying = None
tmdb = None
tools = None
player_elementum = None

_IMPORT_ERRORS = []

try:
    from kodi_actions import (
        perform_kodi_action,
        keyboard_type_char, keyboard_backspace, keyboard_enter,
        keyboard_clear, keyboard_send_text,
    )
    import kodi_actions
except Exception as e:
    _IMPORT_ERRORS.append(f"kodi_actions: {e}")

try:
    from shortcuts import handle_shortcut
    import shortcuts
except Exception as e:
    _IMPORT_ERRORS.append(f"shortcuts: {e}")

try:
    from subtitles import handle_subtitles
    import subtitles
except Exception as e:
    _IMPORT_ERRORS.append(f"subtitles: {e}")

try:
    from nowplaying import get_nowplaying_string
    import nowplaying
except Exception as e:
    _IMPORT_ERRORS.append(f"nowplaying: {e}")

try:
    import tmdb
except Exception as e:
    _IMPORT_ERRORS.append(f"tmdb: {e}")

try:
    import tools
except Exception as e:
    _IMPORT_ERRORS.append(f"tools: {e}")

try:
    from player_elementum import play_movie_by_tmdb, play_tvshow_episode_by_tmdb, open_tvshow_by_tmdb
    import player_elementum
except Exception as e:
    _IMPORT_ERRORS.append(f"player_elementum: {e}")

if _IMPORT_ERRORS:
    _log_msg = "[routes.py] Import warnings: " + " | ".join(_IMPORT_ERRORS)
    xbmc.log(_log_msg, xbmc.LOGWARNING)


def _log(msg: str, level=xbmc.LOGERROR):
    xbmc.log(f"[service.kronos.remote] {msg}", level)


def load_interface_html() -> str:
    """
    IMPORTANT: no caching here. Always read file to avoid 'old JS' problem.
    """
    try:
        if not os.path.isfile(INTERFACE_HTML_PATH):
            _log(f"interface.html not found: {INTERFACE_HTML_PATH}", xbmc.LOGERROR)
            return "<h1>Kronos Remote LAN</h1><p>interface.html missing.</p>"

        with open(INTERFACE_HTML_PATH, "r", encoding="utf-8") as f:
            return f.read()

    except Exception as exc:
        _log(f"Failed to load interface.html: {exc}", xbmc.LOGERROR)
        return "<h1>Kronos Remote LAN</h1><p>Error loading interface.html.</p>"


class KronosRequestHandler(BaseHTTPRequestHandler):
    server_version = "KronosRemoteHTTP/1.0"

    def log_message(self, format, *args):
        return

    def _send_bytes(self, code: int, data: bytes, content_type: str):
        try:
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                return
        except Exception:
            return

    def _send_text(self, code: int, body: str, content_type: str = "text/plain; charset=utf-8"):
        self._send_bytes(code, body.encode("utf-8", errors="replace"), content_type)

    def _send_json(self, code: int, obj: dict):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8", errors="replace")
        self._send_bytes(code, data, "application/json; charset=utf-8")

    def _read_json_body(self) -> dict | None:
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
            if length <= 0:
                return {}
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
        except Exception:
            return None

    # ---------- GET ----------

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path or "/"
        qs = parse_qs(parsed.query)

        if path in ("/", "/index.html"):
            html = load_interface_html()
            self._send_text(200, html, "text/html; charset=utf-8")
            return

        if path == "/ping":
            self._send_text(200, "pong")
            return

        if path == "/nowplaying":
            if nowplaying is None:
                self._send_text(500, "nowplaying module not available")
                return
            try:
                txt = get_nowplaying_string()
            except Exception as exc:
                _log(f"/nowplaying failed: {exc}", xbmc.LOGERROR)
                txt = "Idle"
            self._send_text(200, txt, "text/plain; charset=utf-8")
            return

        # ---------- API: Movies / TV ----------
        if path == "/api/movies/trending":
            if tmdb is None:
                self._send_json(500, {"error": "tmdb module not available"})
                return
            page = int(qs.get("page", ["1"])[0] or "1")
            try:
                self._send_json(200, tmdb.trending_movies(page))
            except Exception as exc:
                _log(f"/api/movies/trending failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tmdb error"})
            return

        if path == "/api/tv/trending":
            if tmdb is None:
                self._send_json(500, {"error": "tmdb module not available"})
                return
            page = int(qs.get("page", ["1"])[0] or "1")
            try:
                self._send_json(200, tmdb.trending_tv(page))
            except Exception as exc:
                _log(f"/api/tv/trending failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tmdb error"})
            return

        if path == "/api/search":
            if tmdb is None:
                self._send_json(500, {"error": "tmdb module not available"})
                return
            typ = (qs.get("type", ["movie"])[0] or "movie").strip().lower()
            q = (qs.get("q", [""])[0] or "").strip()
            page = int(qs.get("page", ["1"])[0] or "1")

            try:
                if typ == "tv":
                    self._send_json(200, tmdb.search_tv(q, page))
                else:
                    self._send_json(200, tmdb.search_movies(q, page))
            except Exception as exc:
                _log(f"/api/search failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tmdb error"})
            return

        if path == "/api/details":
            if tmdb is None:
                self._send_json(500, {"error": "tmdb module not available"})
                return
            typ = (qs.get("type", ["movie"])[0] or "movie").strip().lower()
            tmdb_id = int(qs.get("id", ["0"])[0] or "0")

            if tmdb_id <= 0:
                self._send_json(400, {"error": "missing id"})
                return

            try:
                if typ == "tv":
                    self._send_json(200, tmdb.tv_details(tmdb_id))
                else:
                    self._send_json(200, tmdb.movie_details(tmdb_id))
            except Exception as exc:
                _log(f"/api/details failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tmdb error"})
            return

        # ---------- API: Tools ----------
        if path == "/api/tools/vpn/status":
            if tools is None:
                self._send_json(500, {"error": "tools module not available"})
                return
            try:
                self._send_json(200, tools.vpn_status())
            except Exception as exc:
                _log(f"/api/tools/vpn/status failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tools error"})
            return

        self._send_text(404, "Not found")

    # ---------- POST ----------

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path or "/"
        qs = parse_qs(parsed.query)

        if path == "/nav":
            raw_key = (qs.get("key", [""])[0] or "")
            key = raw_key.strip()

            if not key:
                self._send_text(400, "missing key")
                return

            # Check module availability
            if kodi_actions is None:
                self._send_text(500, "kodi_actions module not available")
                return

            # play keys
            low = key.lower()
            try:
                if low.startswith("play_movie:"):
                    if player_elementum is None:
                        self._send_text(500, "player_elementum module not available")
                        return
                    tmdb_id = int(key.split(":", 1)[1].strip() or "0")
                    ok = play_movie_by_tmdb(tmdb_id)
                    self._send_text(200 if ok else 400, "ok" if ok else "fail")
                    return

                if low.startswith("play_tv:"):
                    if player_elementum is None:
                        self._send_text(500, "player_elementum module not available")
                        return
                    tmdb_id = int(key.split(":", 1)[1].strip() or "0")
                    ok = open_tvshow_by_tmdb(tmdb_id)
                    self._send_text(200 if ok else 400, "ok" if ok else "fail")
                    return
            except Exception as exc:
                _log(f"/nav play key exception key={key} exc={exc}", xbmc.LOGERROR)
                self._send_text(400, "fail")
                return

            # normal keys
            try:
                handled = False
                if shortcuts is not None:
                    try:
                        handled = handle_shortcut(key)
                    except Exception:
                        pass
                if not handled and subtitles is not None:
                    try:
                        handled = handle_subtitles(key)
                    except Exception:
                        pass
                if not handled:
                    handled = perform_kodi_action(key)

                ok = bool(handled)
                self._send_text(200 if ok else 400, "ok" if ok else "unknown key")
                return
            except Exception as exc:
                _log(f"/nav normal key exception key={key} exc={exc}", xbmc.LOGERROR)
                self._send_text(400, "fail")
                return

        if path == "/api/play":
            if player_elementum is None:
                self._send_json(500, {"error": "player_elementum module not available"})
                return

            body = self._read_json_body()
            if body is None:
                self._send_json(400, {"error": "invalid json"})
                return

            typ = (body.get("type") or "movie").strip().lower()
            tmdb_id = int(body.get("id") or 0)

            try:
                if typ == "tv_episode":
                    season = int(body.get("season") or 0)
                    episode = int(body.get("episode") or 0)
                    ok = play_tvshow_episode_by_tmdb(tmdb_id, season, episode)
                    self._send_json(200 if ok else 400, {"ok": bool(ok)})
                    return

                ok = play_movie_by_tmdb(tmdb_id)
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/api/play failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "play error"})
            return

        if path == "/api/tools/vpn/reconnect":
            if tools is None:
                self._send_json(500, {"error": "tools module not available"})
                return
            try:
                ok = tools.vpn_reconnect()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/api/tools/vpn/reconnect failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tools error"})
            return

        # ---- Keyboard input endpoints ----

        if path == "/keyboard/type":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions not available"})
                return
            body = self._read_json_body()
            if body is None:
                self._send_json(400, {"ok": False, "error": "invalid json"})
                return
            char = body.get("char", "")
            if not char:
                self._send_json(400, {"ok": False, "error": "missing char"})
                return
            try:
                ok = keyboard_type_char(char)
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/keyboard/type failed: {exc}")
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/backspace":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions not available"})
                return
            try:
                ok = keyboard_backspace()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/keyboard/backspace failed: {exc}")
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/enter":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions not available"})
                return
            try:
                ok = keyboard_enter()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/keyboard/enter failed: {exc}")
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/clear":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions not available"})
                return
            try:
                ok = keyboard_clear()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/keyboard/clear failed: {exc}")
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/sendtext":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions not available"})
                return
            body = self._read_json_body()
            if body is None:
                self._send_json(400, {"ok": False, "error": "invalid json"})
                return
            text = body.get("text", "")
            done = bool(body.get("done", True))
            try:
                ok = keyboard_send_text(text, done)
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/keyboard/sendtext failed: {exc}")
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/api/tools/reboot":
            if tools is None:
                self._send_json(500, {"error": "tools module not available"})
                return
            try:
                ok = tools.restart()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/api/tools/reboot failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tools error"})
            return

        if path == "/api/tools/shutdown":
            if tools is None:
                self._send_json(500, {"error": "tools module not available"})
                return
            try:
                ok = tools.shutdown()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                _log(f"/api/tools/shutdown failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"error": "tools error"})
            return

        self._send_text(404, "Not found")
