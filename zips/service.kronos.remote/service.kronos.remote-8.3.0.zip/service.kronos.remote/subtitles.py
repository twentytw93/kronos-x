# -*- coding: utf-8 -*-
# Kronos Remote LAN – Subtitles
# v4.0.0
#
# مسؤوليات هذا الملف فقط:
# - تنفيذ subs_download بنفس المنطق القديم:
#   * فقط إذا في فيديو شغال
#   * فقط إذا التشغيل من plugin.video.elementum
#   * فتح subtitlesearch
#   * fallback لـ XBMC.Subtitles.Search
#
# ممنوع فيه:
# - HTTP
# - Routing
# - Kodi actions mapping
# - Shortcuts

from __future__ import annotations

import xbmc
import xbmcaddon

# ---------------------------------------------------------------------------
# Add-on metadata
# ---------------------------------------------------------------------------

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def _download_subtitles() -> bool:
    """
    Trigger subtitle download, but ONLY when media playback is happening
    from plugin.video.elementum.
    """
    try:
        player = xbmc.Player()

        # 1) Must be playing video
        if not player.isPlayingVideo():
            xbmc.log(
                f"[{ADDON_ID}] _download_subtitles: no video playing, aborting.",
                xbmc.LOGDEBUG,
            )
            return False

        # 2) Must be Elementum playback
        current_path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""
        if not current_path.startswith("plugin://plugin.video.elementum"):
            xbmc.log(
                f"[{ADDON_ID}] _download_subtitles: playback is not from plugin.video.elementum, aborting. Path={current_path}",
                xbmc.LOGDEBUG,
            )
            return False

        # 3) We are in Elementum playback -> trigger subtitle search
        xbmc.log(
            f"[{ADDON_ID}] _download_subtitles: Elementum playback detected, opening subtitle search window...",
            xbmc.LOGDEBUG,
        )

        xbmc.executebuiltin("ActivateWindow(subtitlesearch)")
        xbmc.log(
            f"[{ADDON_ID}] _download_subtitles: subtitle search window activated.",
            xbmc.LOGDEBUG,
        )

        xbmc.sleep(100)
        return True

    except Exception as exc:
        xbmc.log(
            f"[{ADDON_ID}] Failed to download subtitles: {exc}",
            xbmc.LOGERROR,
        )

        # Last resort: try the basic Kodi subtitle search
        try:
            xbmc.executebuiltin("XBMC.Subtitles.Search")
            xbmc.log(
                f"[{ADDON_ID}] _download_subtitles: fallback XBMC.Subtitles.Search triggered.",
                xbmc.LOGDEBUG,
            )
            return True
        except Exception:
            xbmc.log(
                f"[{ADDON_ID}] _download_subtitles: fallback subtitle search also failed.",
                xbmc.LOGERROR,
            )
            return False


def handle_subtitles(key: str) -> bool:
    """
    Handle subtitle-related keys.

    Returns True if handled, False otherwise.
    """
    key = (key or "").strip().lower()
    if not key:
        return False

    if key == "subs_download":
        return _download_subtitles()

    return False
