# -*- coding: utf-8 -*-
# Kronos Remote LAN – Shortcuts
# v4.0.0
#
# مسؤوليات هذا الملف فقط:
# - فتح أقسام / إضافات محددة (Elementum, IPTV, WatchNixtoon2)
#
# ممنوع فيه:
# - HTTP
# - Play logic
# - Subtitles
# - Navigation actions

from __future__ import annotations

import xbmc
import xbmcaddon

# ---------------------------------------------------------------------------
# Add-on metadata
# ---------------------------------------------------------------------------

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


# ---------------------------------------------------------------------------
# Shortcut handlers
# ---------------------------------------------------------------------------

def _open_elementum_movies() -> bool:
    try:
        xbmc.executebuiltin(
            'ActivateWindow(Videos,"plugin://plugin.video.elementum/movies/",return)'
        )
        xbmc.log(
            f"[{ADDON_ID}] Shortcut: Elementum Movies",
            xbmc.LOGDEBUG,
        )
        return True
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_ID}] Failed to open Elementum Movies: {exc}",
            xbmc.LOGERROR,
        )
        return False


def _open_elementum_tvshows() -> bool:
    try:
        xbmc.executebuiltin(
            'ActivateWindow(Videos,"plugin://plugin.video.elementum/shows/",return)'
        )
        xbmc.log(
            f"[{ADDON_ID}] Shortcut: Elementum TV Shows",
            xbmc.LOGDEBUG,
        )
        return True
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_ID}] Failed to open Elementum TV Shows: {exc}",
            xbmc.LOGERROR,
        )
        return False


def _open_watchnixtoon2() -> bool:
    try:
        xbmc.executebuiltin(
            'ActivateWindow(Videos,"plugin://plugin.video.watchnixtoons2/",return)'
        )
        xbmc.log(
            f"[{ADDON_ID}] Shortcut: WatchNixtoon2",
            xbmc.LOGDEBUG,
        )
        return True
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_ID}] Failed to open WatchNixtoon2: {exc}",
            xbmc.LOGERROR,
        )
        return False


def _open_iptv_simple() -> bool:
    try:
        xbmc.executebuiltin("ActivateWindow(TVChannels)")
        xbmc.log(
            f"[{ADDON_ID}] Shortcut: IPTV Simple (TVChannels)",
            xbmc.LOGDEBUG,
        )
        return True
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_ID}] Failed to open IPTV Simple / TVChannels: {exc}",
            xbmc.LOGERROR,
        )
        return False


# ---------------------------------------------------------------------------
# Public dispatcher
# ---------------------------------------------------------------------------

def handle_shortcut(key: str) -> bool:
    """
    Handle app shortcut keys.

    Returns True if handled, False otherwise.
    """
    key = (key or "").strip().lower()
    if not key:
        return False

    if key == "elem_movies":
        return _open_elementum_movies()

    if key == "elem_tv":
        return _open_elementum_tvshows()

    if key == "wnt":
        return _open_watchnixtoon2()

    if key == "iptv":
        return _open_iptv_simple()

    return False
