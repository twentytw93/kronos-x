# -*- coding: utf-8 -*-
# Kronos Remote LAN – Elementum Player Bridge
# v4.0.7 - PATCHED
#
# Fixes:
# - _stop_all_playback: Fixed logic error where empty list [] wasn't handled
# - Now checks: if not isinstance(players, list) or not players:
# - Added defensive logging for stop failures

from __future__ import annotations

import json
import time

import xbmc
import xbmcaddon


ADDON_ID = xbmcaddon.Addon().getAddonInfo("id")
ELEMENTUM_ID = "plugin.video.elementum"

_MOVIE_PLAY = "plugin://plugin.video.elementum/library/play/movie/{tmdb}"
_TVSHOW_OPEN = "plugin://plugin.video.elementum/show/{tmdb}"

# FIX: correct endpoint is /library/play/show/{tmdb}/season/{season}/episode/{episode}
_TV_EP_PLAY = "plugin://plugin.video.elementum/library/play/show/{tmdb}/season/{season}/episode/{episode}"


def _log(msg: str, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def _busy_visible() -> bool:
    """
    Block play while Kodi is busy (crash/lock protection).
    Covers BusyDialog + progress dialogs.
    """
    try:
        if xbmc.getCondVisibility("Window.IsVisible(busydialog)"):
            return True
        if xbmc.getCondVisibility("Window.IsVisible(busydialognocancel)"):
            return True
        if xbmc.getCondVisibility("Window.IsVisible(progressdialog)"):
            return True
        if xbmc.getCondVisibility("Window.IsVisible(progressdialogextended)"):
            return True
        return False
    except Exception:
        return False


def _jsonrpc(method: str, params: dict | None = None) -> dict:
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params is not None:
            req["params"] = params
        raw = xbmc.executeJSONRPC(json.dumps(req))
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _stop_all_playback(timeout_ms: int = 2000) -> bool:
    """
    Stops any active Kodi player (audio/video) via JSON-RPC.
    Returns True if playback is stopped (or no active player), False if it couldn't confirm stop.
    
    FIXED: Now properly handles empty list [] case
    """
    try:
        data = _jsonrpc("Player.GetActivePlayers")
        players = data.get("result")

        # FIXED: Empty list [] passes isinstance([], list) == True
        # So we must check: not isinstance OR not players (empty check)
        if not isinstance(players, list) or not players:
            # No active players or invalid response - try best-effort stop
            if not isinstance(players, list):
                _log("Stop playback: JSON-RPC returned non-list, attempting fallback stop", xbmc.LOGDEBUG)
                try:
                    xbmc.executebuiltin("PlayerControl(Stop)")
                    xbmc.sleep(200)
                except Exception as exc:
                    _log(f"Fallback stop failed: {exc}", xbmc.LOGWARNING)
            return True

        # Stop all active players
        for p in players:
            if not isinstance(p, dict):
                continue
            pid = p.get("playerid")
            try:
                pid = int(pid)
            except Exception:
                continue
            _log(f"Stopping player {pid}", xbmc.LOGDEBUG)
            _jsonrpc("Player.Stop", {"playerid": pid})

        # Wait until players are gone (avoid race where new playback starts while old is stopping)
        deadline = time.monotonic() + (max(0, int(timeout_ms)) / 1000.0)
        while time.monotonic() < deadline:
            data2 = _jsonrpc("Player.GetActivePlayers")
            players2 = data2.get("result")
            # FIXED: Check both isinstance and empty
            if isinstance(players2, list) and not players2:
                _log("All players stopped successfully", xbmc.LOGDEBUG)
                return True
            xbmc.sleep(100)

        _log("Stop playback: timeout waiting for players to stop", xbmc.LOGWARNING)
        return False
    except Exception as exc:
        _log(f"Stop playback failed: {exc}", xbmc.LOGERROR)
        return False


def _has_elementum() -> bool:
    try:
        return bool(xbmc.getCondVisibility(f"System.HasAddon({ELEMENTUM_ID})"))
    except Exception:
        return False


def _is_elementum_enabled() -> bool:
    try:
        return bool(xbmc.getCondVisibility(f"System.AddonIsEnabled({ELEMENTUM_ID})"))
    except Exception:
        return False


def play_movie_by_tmdb(tmdb_id: int) -> bool:
    tmdb_id = int(tmdb_id or 0)
    if tmdb_id <= 0:
        return False

    if _busy_visible():
        _log("Play blocked: BusyDialog/Progress visible.", xbmc.LOGINFO)
        return False

    if not _has_elementum():
        _log("Elementum not found (System.HasAddon=false).", xbmc.LOGERROR)
        return False

    if not _is_elementum_enabled():
        _log("Elementum installed but DISABLED (System.AddonIsEnabled=false).", xbmc.LOGERROR)
        return False

    # Kill any active playback before launching Elementum
    if not _stop_all_playback():
        _log("Warning: active playback may not have fully stopped before Elementum launch.", xbmc.LOGWARNING)

    try:
        url = _MOVIE_PLAY.format(tmdb=tmdb_id)
        _log(f"Play movie via Elementum: {url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'PlayMedia("{url}")')
        return True
    except Exception as exc:
        _log(f"Play movie failed: {exc}", xbmc.LOGERROR)
        return False


def open_tvshow_by_tmdb(tmdb_id: int) -> bool:
    tmdb_id = int(tmdb_id or 0)
    if tmdb_id <= 0:
        return False

    if _busy_visible():
        _log("Open TV blocked: BusyDialog/Progress visible.", xbmc.LOGINFO)
        return False

    if not _has_elementum():
        _log("Elementum not found (System.HasAddon=false).", xbmc.LOGERROR)
        return False

    if not _is_elementum_enabled():
        _log("Elementum installed but DISABLED (System.AddonIsEnabled=false).", xbmc.LOGERROR)
        return False

    # Kill any active playback before opening Elementum
    if not _stop_all_playback():
        _log("Warning: active playback may not have fully stopped before Elementum launch.", xbmc.LOGWARNING)

    try:
        url = _TVSHOW_OPEN.format(tmdb=tmdb_id)
        _log(f"Open TV show in Elementum: {url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'ActivateWindow(Videos,"{url}",return)')
        return True
    except Exception as exc:
        _log(f"Open TV show failed: {exc}", xbmc.LOGERROR)
        return False


def play_tvshow_episode_by_tmdb(tmdb_id: int, season: int, episode: int) -> bool:
    tmdb_id = int(tmdb_id or 0)
    season = int(season or 0)
    episode = int(episode or 0)

    if tmdb_id <= 0 or season <= 0 or episode <= 0:
        return False

    if _busy_visible():
        _log("Play episode blocked: BusyDialog/Progress visible.", xbmc.LOGINFO)
        return False

    if not _has_elementum():
        _log("Elementum not found (System.HasAddon=false).", xbmc.LOGERROR)
        return False

    if not _is_elementum_enabled():
        _log("Elementum installed but DISABLED (System.AddonIsEnabled=false).", xbmc.LOGERROR)
        return False

    # Kill any active playback before launching Elementum
    if not _stop_all_playback():
        _log("Warning: active playback may not have fully stopped before Elementum launch.", xbmc.LOGWARNING)

    try:
        url = _TV_EP_PLAY.format(tmdb=tmdb_id, season=season, episode=episode)
        _log(f"Play TV episode via Elementum: {url}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'PlayMedia("{url}")')
        return True
    except Exception as exc:
        _log(f"Play TV episode failed: {exc}", xbmc.LOGERROR)
        return False
