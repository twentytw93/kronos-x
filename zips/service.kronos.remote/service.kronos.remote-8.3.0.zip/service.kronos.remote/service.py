# -*- coding: utf-8 -*-
# Kronos Remote LAN – Service (Pages + API Router)
# Kodi 21.x Omega / LibreELEC compatible
#
# v4.1.4 - CLEANED
#
# Cleanup:
# - Removed redundant `import tools as _tools; tools = _tools` alias pattern
#   (direct `import tools` achieves the same result)

from __future__ import annotations

import os
import threading
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import xbmc
import xbmcaddon
import xbmcvfs

# ---------------------------------------------------------------------------
# Add-on metadata / paths
# ---------------------------------------------------------------------------

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

HOST = "0.0.0.0"
PORT = 9001

ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
RESOURCES_DIR = os.path.join(ADDON_PATH, "resources")

INTERFACE_HTML_PATH = os.path.join(RESOURCES_DIR, "interface.html")
MOVIES_HTML_PATH = os.path.join(RESOURCES_DIR, "movies.html")
TV_HTML_PATH = os.path.join(RESOURCES_DIR, "tv.html")

# Cache HTML in memory
_HTML_CACHE: dict[str, str] = {}

# Global lock to serialize Kodi calls (HTTP server is multi-threaded)
_KODI_LOCK = threading.Lock()

# ---------------------------------------------------------------------------
# Optional module imports (hard requirements for full functionality)
# ---------------------------------------------------------------------------

_MOD_IMPORT_ERRORS = []

try:
    import kodi_actions
except Exception as e:
    kodi_actions = None
    _MOD_IMPORT_ERRORS.append(f"kodi_actions import failed: {e}")

try:
    import nowplaying
except Exception as e:
    nowplaying = None
    _MOD_IMPORT_ERRORS.append(f"nowplaying import failed: {e}")

try:
    import tmdb
except Exception as e:
    tmdb = None
    _MOD_IMPORT_ERRORS.append(f"tmdb import failed: {e}")

try:
    import tools
except Exception as e:
    tools = None
    _MOD_IMPORT_ERRORS.append(f"tools import failed: {e}")

if _MOD_IMPORT_ERRORS:
    xbmc.log(f"[{ADDON_ID}] Module import warnings: " + " | ".join(_MOD_IMPORT_ERRORS), xbmc.LOGWARNING)

# ---------------------------------------------------------------------------
# HTML loader
# ---------------------------------------------------------------------------


def _load_html(abs_path: str, cache_key: str) -> str:
    if cache_key in _HTML_CACHE:
        return _HTML_CACHE[cache_key]

    try:
        if not os.path.isfile(abs_path):
            xbmc.log(f"[{ADDON_ID}] HTML missing: {abs_path}", xbmc.LOGERROR)
            return "<h1>Kronos Remote LAN</h1><p>HTML file missing.</p>"

        with open(abs_path, "r", encoding="utf-8") as f:
            _HTML_CACHE[cache_key] = f.read()
        return _HTML_CACHE[cache_key]
    except Exception as exc:
        xbmc.log(f"[{ADDON_ID}] HTML load failed ({cache_key}): {exc}", xbmc.LOGERROR)
        return "<h1>Kronos Remote LAN</h1><p>Error loading HTML.</p>"


def load_interface_html() -> str:
    return _load_html(INTERFACE_HTML_PATH, "interface.html")


def load_movies_html() -> str:
    return _load_html(MOVIES_HTML_PATH, "movies.html")


def load_tv_html() -> str:
    return _load_html(TV_HTML_PATH, "tv.html")


# ---------------------------------------------------------------------------
# JSON-RPC helpers (for seekbar)
# ---------------------------------------------------------------------------


def _jsonrpc(method: str, params: dict | None = None) -> dict:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        data = json.loads(raw) if raw else {}
    except Exception:
        data = {}
    return data if isinstance(data, dict) else {}


def _hms_to_seconds(t: dict) -> int:
    try:
        h = int(t.get("hours", 0) or 0)
        m = int(t.get("minutes", 0) or 0)
        s = int(t.get("seconds", 0) or 0)
        return (h * 3600) + (m * 60) + s
    except Exception:
        return 0


def _get_active_player() -> tuple[int | None, str]:
    """
    Returns (playerid, playertype) or (None,"")
    playertype is usually "video" or "audio".
    """
    try:
        r = _jsonrpc("Player.GetActivePlayers")
        lst = r.get("result") or []
        if not isinstance(lst, list) or not lst:
            return None, ""
        first = lst[0] if isinstance(lst[0], dict) else {}
        pid = first.get("playerid", None)
        ptype = first.get("type", "") or ""
        try:
            pid = int(pid)
        except Exception:
            pid = None
        return pid, ptype
    except Exception:
        return None, ""


def _build_status_fallback() -> dict:
    """
    Fallback if nowplaying.py doesn't expose a status dict yet.
    CRITICAL: This function is called within _KODI_LOCK context.
    """
    player = xbmc.Player()
    is_playing = bool(player.isPlayingVideo() or player.isPlayingAudio())

    path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""
    is_pvr = bool(path.startswith("pvr://"))

    pid, ptype = _get_active_player()
    time_sec = 0
    duration_sec = 0
    percent = 0.0

    if pid is not None:
        props = _jsonrpc(
            "Player.GetProperties",
            {
                "playerid": pid,
                "properties": ["time", "totaltime", "percentage", "speed"],
            },
        ).get("result") or {}

        if isinstance(props, dict):
            time_sec = _hms_to_seconds(props.get("time") or {})
            duration_sec = _hms_to_seconds(props.get("totaltime") or {})
            try:
                percent = float(props.get("percentage", 0.0) or 0.0)
            except Exception:
                percent = 0.0

    seekable = bool(is_playing and (not is_pvr) and duration_sec > 0)

    title = xbmc.getInfoLabel("Player.Title") or ""
    label = title.strip() if title.strip() else ("Connected · No playback" if not is_playing else "Playing")

    return {
        "ok": True,
        "playing": is_playing,
        "type": ptype or ("video" if player.isPlayingVideo() else ("audio" if player.isPlayingAudio() else "")),
        "path": path,
        "is_pvr": is_pvr,
        "seekable": seekable,
        "time_sec": int(time_sec),
        "duration_sec": int(duration_sec),
        "percent": float(percent),
        "label": label,
        "show_seekbar": bool(seekable),
    }


def _get_status_payload() -> dict:
    """
    Prefer nowplaying module status if available, otherwise fallback.
    CRITICAL: This function is called within _KODI_LOCK context.
    """
    if nowplaying is None:
        return _build_status_fallback()

    # try get_status(lock)
    try:
        if hasattr(nowplaying, "get_status"):
            return nowplaying.get_status(_KODI_LOCK)
    except TypeError:
        try:
            return nowplaying.get_status()
        except Exception:
            pass
    except Exception:
        pass

    # try get_playback_status(lock)
    try:
        if hasattr(nowplaying, "get_playback_status"):
            return nowplaying.get_playback_status(_KODI_LOCK)
    except TypeError:
        try:
            return nowplaying.get_playback_status()
        except Exception:
            pass
    except Exception:
        pass

    return _build_status_fallback()


def _seek_to_percent(percent: float) -> dict:
    """
    Seek active player to percent via JSON-RPC.
    Blocked for PVR and non-seekable streams.
    Returns JSON payload.
    CRITICAL: This function is called within _KODI_LOCK context.
    """
    player = xbmc.Player()
    is_playing = bool(player.isPlayingVideo() or player.isPlayingAudio())
    if not is_playing:
        return {"ok": False, "error": "no_playback"}

    path = xbmc.getInfoLabel("Player.FilenameAndPath") or ""
    if path.startswith("pvr://"):
        return {"ok": False, "error": "pvr_not_supported"}

    pid, _ptype = _get_active_player()
    if pid is None:
        return {"ok": False, "error": "no_active_player"}

    # Check duration > 0 (seekable)
    props = _jsonrpc(
        "Player.GetProperties",
        {"playerid": pid, "properties": ["totaltime"]},
    ).get("result") or {}
    duration_sec = _hms_to_seconds((props or {}).get("totaltime") or {})
    if duration_sec <= 0:
        return {"ok": False, "error": "not_seekable"}

    # Clamp percent
    if percent < 0.0:
        percent = 0.0
    if percent > 100.0:
        percent = 100.0

    # Try float percentage first, then fallback to int
    data = _jsonrpc("Player.Seek", {"playerid": pid, "value": {"percentage": float(percent)}})
    if "error" not in data:
        return {"ok": True}

    data = _jsonrpc("Player.Seek", {"playerid": pid, "value": int(round(percent))})
    if "error" not in data:
        return {"ok": True}

    return {"ok": False, "error": "seek_failed"}


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------


class KronosRemoteRequestHandler(BaseHTTPRequestHandler):
    server_version = "KronosRemoteHTTP/1.0"

    def log_message(self, format, *args):
        return

    def _send_bytes(self, code: int, data: bytes, content_type: str):
        try:
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                return
        except Exception:
            return

    def _send_text(self, code: int, body: str, content_type: str = "text/plain; charset=utf-8"):
        self._send_bytes(code, body.encode("utf-8", errors="replace"), content_type)

    def _send_json(self, code: int, obj: dict):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8", errors="replace")
        self._send_bytes(code, data, "application/json; charset=utf-8")

    def _read_json_body(self) -> dict | None:
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
            if length <= 0:
                return {}
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
        except Exception:
            return None

    # ---------------- GET ----------------

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path or "/"
        qs = parse_qs(parsed.query or "")

        if path in ("/", "/index.html"):
            self._send_text(200, load_interface_html(), "text/html; charset=utf-8")
            return

        if path == "/movies.html":
            self._send_text(200, load_movies_html(), "text/html; charset=utf-8")
            return

        if path == "/tv.html":
            self._send_text(200, load_tv_html(), "text/html; charset=utf-8")
            return

        # ---- Basic endpoints ----
        if path == "/ping":
            self._send_text(200, "pong")
            return

        if path == "/nowplaying":
            if nowplaying is None:
                self._send_text(500, "nowplaying module missing")
                return
            try:
                try:
                    text = nowplaying.get_nowplaying_string(_KODI_LOCK)
                except TypeError:
                    text = nowplaying.get_nowplaying_string()
                self._send_text(200, text, "text/plain; charset=utf-8")
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /nowplaying failed: {exc}", xbmc.LOGERROR)
                self._send_text(500, "error")
            return

        if path == "/status":
            try:
                with _KODI_LOCK:
                    payload = _get_status_payload()
                if not isinstance(payload, dict):
                    payload = {"ok": False, "error": "bad_status_payload"}
                self._send_json(200, payload)
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /status failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "status_error"})
            return

        # ---- TMDB API ----

        if path == "/api/movies/trending":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            page = 1
            try:
                if "page" in qs and qs["page"]:
                    page = int(qs["page"][0])
            except Exception:
                page = 1
            try:
                data = tmdb.trending_movies(page=page)
                self._send_json(200, {"ok": True, "page": page, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/movies/trending failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        if path == "/api/tv/trending":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            page = 1
            try:
                if "page" in qs and qs["page"]:
                    page = int(qs["page"][0])
            except Exception:
                page = 1
            try:
                data = tmdb.trending_tv(page=page)
                self._send_json(200, {"ok": True, "page": page, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tv/trending failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        if path == "/api/movies/search":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            query = (qs.get("query", [""])[0] or "").strip()
            if not query:
                self._send_json(400, {"ok": False, "error": "missing query"})
                return
            page = 1
            try:
                if "page" in qs and qs["page"]:
                    page = int(qs["page"][0])
            except Exception:
                page = 1
            try:
                data = tmdb.search_movies(query, page)
                self._send_json(200, {"ok": True, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/movies/search failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        if path == "/api/tv/search":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            query = (qs.get("query", [""])[0] or "").strip()
            if not query:
                self._send_json(400, {"ok": False, "error": "missing query"})
                return
            page = 1
            try:
                if "page" in qs and qs["page"]:
                    page = int(qs["page"][0])
            except Exception:
                page = 1
            try:
                data = tmdb.search_tv(query, page)
                self._send_json(200, {"ok": True, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tv/search failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        # ---- Details / seasons / episodes ----

        if path == "/api/movies/details":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            tmdb_id = None
            try:
                tmdb_id = int(qs.get("id", [""])[0])
            except Exception:
                tmdb_id = None
            if not tmdb_id:
                self._send_json(400, {"ok": False, "error": "missing id"})
                return
            try:
                data = tmdb.movie_details(tmdb_id=tmdb_id)
                self._send_json(200, {"ok": True, "id": tmdb_id, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/movies/details failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        if path == "/api/tv/details":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            tmdb_id = None
            try:
                tmdb_id = int(qs.get("id", [""])[0])
            except Exception:
                tmdb_id = None
            if not tmdb_id:
                self._send_json(400, {"ok": False, "error": "missing id"})
                return
            try:
                data = tmdb.tv_details(tmdb_id=tmdb_id)
                self._send_json(200, {"ok": True, "id": tmdb_id, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tv/details failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        if path == "/api/tv/seasons":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            tmdb_id = None
            try:
                tmdb_id = int(qs.get("id", [""])[0])
            except Exception:
                tmdb_id = None
            if not tmdb_id:
                self._send_json(400, {"ok": False, "error": "missing id"})
                return
            try:
                data = tmdb.tv_seasons(tmdb_id=tmdb_id)
                self._send_json(200, {"ok": True, "id": tmdb_id, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tv/seasons failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        if path == "/api/tv/episodes":
            if tmdb is None:
                self._send_json(500, {"ok": False, "error": "tmdb module missing"})
                return
            tmdb_id = None
            season = None
            try:
                tmdb_id = int(qs.get("id", [""])[0])
            except Exception:
                tmdb_id = None
            try:
                season = int(qs.get("season", [""])[0])
            except Exception:
                season = None
            if not tmdb_id:
                self._send_json(400, {"ok": False, "error": "missing id"})
                return
            if not season:
                self._send_json(400, {"ok": False, "error": "missing season"})
                return
            try:
                data = tmdb.tv_episodes(tmdb_id=tmdb_id, season=season)
                self._send_json(200, {"ok": True, "id": tmdb_id, "season": season, "data": data})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tv/episodes failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tmdb error"})
            return

        self._send_text(404, "Not found")

    # ---------------- POST ----------------

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path or "/"
        qs = parse_qs(parsed.query or "")

        if path == "/nav":
            key = qs.get("key", [""])[0]
            if not key:
                self._send_text(400, "missing key param")
                return

            if kodi_actions is None:
                self._send_text(500, "kodi_actions module missing")
                return

            try:
                ok = kodi_actions.perform_kodi_action(key, _KODI_LOCK)
                if ok:
                    self._send_text(200, "ok")
                else:
                    self._send_text(400, "unknown key")
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /nav failed key={key}: {exc}", xbmc.LOGERROR)
                self._send_text(500, "error")
            return

        if path == "/seek":
            pct_raw = qs.get("percent", [""])[0]
            if pct_raw is None or pct_raw == "":
                self._send_json(400, {"ok": False, "error": "missing_percent"})
                return
            try:
                pct = float(pct_raw)
            except Exception:
                self._send_json(400, {"ok": False, "error": "bad_percent"})
                return

            try:
                with _KODI_LOCK:
                    payload = _seek_to_percent(pct)
                code = 200 if payload.get("ok") else 400
                self._send_json(code, payload)
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /seek failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "seek_error"})
            return

        # ---- Keyboard input endpoints ----

        if path == "/keyboard/type":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions module missing"})
                return
            body = self._read_json_body()
            if body is None:
                self._send_json(400, {"ok": False, "error": "invalid json"})
                return
            char = body.get("char", "")
            if not char:
                self._send_json(400, {"ok": False, "error": "missing char"})
                return
            try:
                ok = kodi_actions.keyboard_type_char(char)
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /keyboard/type failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/backspace":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions module missing"})
                return
            try:
                ok = kodi_actions.keyboard_backspace()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /keyboard/backspace failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/enter":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions module missing"})
                return
            try:
                ok = kodi_actions.keyboard_enter()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /keyboard/enter failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/clear":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions module missing"})
                return
            try:
                ok = kodi_actions.keyboard_clear()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /keyboard/clear failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/keyboard/sendtext":
            if kodi_actions is None:
                self._send_json(500, {"ok": False, "error": "kodi_actions module missing"})
                return
            body = self._read_json_body()
            if body is None:
                self._send_json(400, {"ok": False, "error": "invalid json"})
                return
            text = body.get("text", "")
            done = bool(body.get("done", True))
            try:
                ok = kodi_actions.keyboard_send_text(text, done)
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /keyboard/sendtext failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "keyboard error"})
            return

        if path == "/api/tools/reboot":
            if tools is None:
                self._send_json(500, {"ok": False, "error": "tools module not available"})
                return
            try:
                ok = tools.restart()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tools/reboot failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tools error"})
            return

        if path == "/api/tools/shutdown":
            if tools is None:
                self._send_json(500, {"ok": False, "error": "tools module not available"})
                return
            try:
                ok = tools.shutdown()
                self._send_json(200 if ok else 400, {"ok": bool(ok)})
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] /api/tools/shutdown failed: {exc}", xbmc.LOGERROR)
                self._send_json(500, {"ok": False, "error": "tools error"})
            return

        self._send_text(404, "Not found")


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------


class KronosHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True


class KronosRemoteService(object):
    def __init__(self, host: str = HOST, port: int = PORT):
        self.host = host
        self.port = port
        self._server = None
        self._thread = None

    def start(self) -> bool:
        try:
            self._server = KronosHTTPServer((self.host, self.port), KronosRemoteRequestHandler)
        except Exception as exc:
            xbmc.log(f"[{ADDON_ID}] Bind failed {self.host}:{self.port} - {exc}", xbmc.LOGERROR)
            self._server = None
            return False

        def _run():
            try:
                self._server.serve_forever()
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] HTTP server exception: {exc}", xbmc.LOGERROR)

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()

        xbmc.log(f"[{ADDON_ID}] Kronos Remote LAN started on {self.host}:{self.port}", xbmc.LOGINFO)
        return True

    def stop(self):
        if self._server:
            try:
                self._server.shutdown()
                self._server.server_close()
            except Exception as exc:
                xbmc.log(f"[{ADDON_ID}] Shutdown error: {exc}", xbmc.LOGERROR)
            finally:
                self._server = None

        xbmc.log(f"[{ADDON_ID}] Kronos Remote LAN stopped", xbmc.LOGINFO)


def run():
    monitor = xbmc.Monitor()
    service = KronosRemoteService()

    if not service.start():
        xbmc.log(f"[{ADDON_ID}] Service failed to start.", xbmc.LOGERROR)
        return

    while not monitor.abortRequested():
        if monitor.waitForAbort(1.0):
            break

    service.stop()


if __name__ == "__main__":
    run()
