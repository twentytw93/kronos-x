# -*- coding: utf-8 -*-
# tmdb.py - Kronos Remote LAN
# TMDB fetch + cache + normalize + search
#
# v4.1.1 - PATCHED
# Fixes:
# - Added search_movies() and search_tv() functions
# - Added movie_search and tv_search cache buckets
from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request

TMDB_API_KEY = "6404e1eb808d9bb09f4223bdd7bdd557"
TMDB_BASE = "https://api.themoviedb.org/3"

# Image bases (use from HTML directly)
IMG_W342 = "https://image.tmdb.org/t/p/w342"
IMG_ORIG = "https://image.tmdb.org/t/p/original"

TIMEOUT = 8
CACHE_SECONDS = 120

_cache = {
    "movies_trending": {"ts": 0, "page": None, "data": None},
    "tv_trending": {"ts": 0, "page": None, "data": None},
    "movie_details": {},  # id -> {ts,data}
    "tv_details": {},     # id -> {ts,data}
    "tv_seasons": {},     # id -> {ts,data}
    "tv_episodes": {},    # (id,season) -> {ts,data}
    "movie_search": {},   # (query,page) -> {ts,data}
    "tv_search": {},      # (query,page) -> {ts,data}
}


def _http_get_json(path: str, params: dict) -> dict:
    q = dict(params or {})
    q["api_key"] = TMDB_API_KEY
    url = TMDB_BASE + path + "?" + urllib.parse.urlencode(q)

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "KronosRemoteLAN/1.0",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
        return json.loads(raw)


def _year_from_date(s: str) -> str:
    if not s:
        return ""
    if len(s) >= 4 and s[0:4].isdigit():
        return s[0:4]
    return ""


def _norm_movie(item: dict) -> dict:
    tmdb_id = item.get("id")
    title = item.get("title") or item.get("original_title") or ""
    date = item.get("release_date") or ""
    year = _year_from_date(date)

    poster = item.get("poster_path") or ""
    backdrop = item.get("backdrop_path") or ""

    vote = item.get("vote_average")
    rating = None
    try:
        rating = round(float(vote), 1)
    except Exception:
        rating = None

    return {
        "id": tmdb_id,
        "title": title,
        "year": year,
        "overview": item.get("overview") or "",
        "rating": rating,
        "poster_path": poster,
        "backdrop_path": backdrop,
        "poster_w342": (IMG_W342 + poster) if poster else "",
        "backdrop": (IMG_ORIG + backdrop) if backdrop else "",
    }


def _norm_tv(item: dict) -> dict:
    tmdb_id = item.get("id")
    title = item.get("name") or item.get("original_name") or ""
    date = item.get("first_air_date") or ""
    year = _year_from_date(date)

    poster = item.get("poster_path") or ""
    backdrop = item.get("backdrop_path") or ""

    vote = item.get("vote_average")
    rating = None
    try:
        rating = round(float(vote), 1)
    except Exception:
        rating = None

    return {
        "id": tmdb_id,
        "title": title,
        "year": year,
        "overview": item.get("overview") or "",
        "rating": rating,
        "poster_path": poster,
        "backdrop_path": backdrop,
        "poster_w342": (IMG_W342 + poster) if poster else "",
        "backdrop": (IMG_ORIG + backdrop) if backdrop else "",
    }


def trending_movies(page: int = 1) -> dict:
    now = int(time.time())
    c = _cache["movies_trending"]
    if c["data"] is not None and c["page"] == page and (now - c["ts"]) < CACHE_SECONDS:
        return c["data"]

    data = _http_get_json("/trending/movie/week", {"page": max(1, int(page))})
    results = data.get("results") or []
    out = {
        "page": data.get("page", page),
        "total_pages": data.get("total_pages", 1),
        "items": [_norm_movie(x) for x in results],
    }

    c["ts"] = now
    c["page"] = page
    c["data"] = out
    return out


def trending_tv(page: int = 1) -> dict:
    now = int(time.time())
    c = _cache["tv_trending"]
    if c["data"] is not None and c["page"] == page and (now - c["ts"]) < CACHE_SECONDS:
        return c["data"]

    data = _http_get_json("/trending/tv/week", {"page": max(1, int(page))})
    results = data.get("results") or []
    out = {
        "page": data.get("page", page),
        "total_pages": data.get("total_pages", 1),
        "items": [_norm_tv(x) for x in results],
    }

    c["ts"] = now
    c["page"] = page
    c["data"] = out
    return out


def movie_details(tmdb_id: int) -> dict:
    tmdb_id = int(tmdb_id)
    now = int(time.time())
    bucket = _cache["movie_details"].get(tmdb_id)
    if bucket and (now - bucket["ts"]) < CACHE_SECONDS:
        return bucket["data"]

    data = _http_get_json(f"/movie/{tmdb_id}", {"append_to_response": ""})

    poster = data.get("poster_path") or ""
    backdrop = data.get("backdrop_path") or ""

    genres = data.get("genres") or []
    genre_names = [g.get("name") for g in genres if g.get("name")]

    out = {
        "id": tmdb_id,
        "title": data.get("title") or data.get("original_title") or "",
        "year": _year_from_date(data.get("release_date") or ""),
        "overview": data.get("overview") or "",
        "rating": round(float(data.get("vote_average") or 0.0), 1),
        "runtime": int(data.get("runtime") or 0),
        "genres": genre_names,
        "poster_w342": (IMG_W342 + poster) if poster else "",
        "backdrop": (IMG_ORIG + backdrop) if backdrop else "",
    }

    _cache["movie_details"][tmdb_id] = {"ts": now, "data": out}
    return out


def tv_details(tmdb_id: int) -> dict:
    tmdb_id = int(tmdb_id)
    now = int(time.time())
    bucket = _cache["tv_details"].get(tmdb_id)
    if bucket and (now - bucket["ts"]) < CACHE_SECONDS:
        return bucket["data"]

    data = _http_get_json(f"/tv/{tmdb_id}", {"append_to_response": ""})

    poster = data.get("poster_path") or ""
    backdrop = data.get("backdrop_path") or ""

    genres = data.get("genres") or []
    genre_names = [g.get("name") for g in genres if g.get("name")]

    runtimes = data.get("episode_run_time") or []
    runtime = 0
    try:
        if runtimes:
            runtime = int(runtimes[0] or 0)
    except Exception:
        runtime = 0

    out = {
        "id": tmdb_id,
        "title": data.get("name") or data.get("original_name") or "",
        "year": _year_from_date(data.get("first_air_date") or ""),
        "overview": data.get("overview") or "",
        "rating": round(float(data.get("vote_average") or 0.0), 1),
        "runtime": runtime,
        "genres": genre_names,
        "poster_w342": (IMG_W342 + poster) if poster else "",
        "backdrop": (IMG_ORIG + backdrop) if backdrop else "",
    }

    _cache["tv_details"][tmdb_id] = {"ts": now, "data": out}
    return out


def tv_seasons(tmdb_id: int) -> dict:
    tmdb_id = int(tmdb_id)
    now = int(time.time())
    bucket = _cache["tv_seasons"].get(tmdb_id)
    if bucket and (now - bucket["ts"]) < CACHE_SECONDS:
        return bucket["data"]

    data = _http_get_json(f"/tv/{tmdb_id}", {"append_to_response": ""})
    seasons = data.get("seasons") or []

    items = []
    for s in seasons:
        sn = s.get("season_number")
        if sn is None:
            continue
        try:
            sn_int = int(sn)
        except Exception:
            continue
        if sn_int <= 0:
            continue
        items.append(
            {
                "season_number": sn_int,
                "name": s.get("name") or f"Season {sn_int}",
                "episode_count": int(s.get("episode_count") or 0),
            }
        )

    items.sort(key=lambda x: x.get("season_number", 0))
    out = {"items": items}

    _cache["tv_seasons"][tmdb_id] = {"ts": now, "data": out}
    return out


def tv_episodes(tmdb_id: int, season: int) -> dict:
    tmdb_id = int(tmdb_id)
    season = int(season)
    now = int(time.time())

    key = (tmdb_id, season)
    bucket = _cache["tv_episodes"].get(key)
    if bucket and (now - bucket["ts"]) < CACHE_SECONDS:
        return bucket["data"]

    data = _http_get_json(f"/tv/{tmdb_id}/season/{season}", {"append_to_response": ""})
    eps = data.get("episodes") or []

    items = []
    for e in eps:
        en = e.get("episode_number")
        if en is None:
            continue
        try:
            en_int = int(en)
        except Exception:
            continue
        if en_int <= 0:
            continue
        items.append(
            {
                "episode_number": en_int,
                "name": e.get("name") or f"Episode {en_int}",
                "overview": e.get("overview") or "",
            }
        )

    items.sort(key=lambda x: x.get("episode_number", 0))
    out = {"season": season, "items": items}

    _cache["tv_episodes"][key] = {"ts": now, "data": out}
    return out


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search_movies(query: str, page: int = 1) -> dict:
    """Search for movies by title. Cached per (query, page)."""
    query = query.strip()
    if not query:
        return {"page": page, "total_pages": 0, "items": []}

    page = max(1, int(page))
    now = int(time.time())
    key = (query, page)
    bucket = _cache["movie_search"].get(key)

    if bucket and (now - bucket["ts"]) < CACHE_SECONDS:
        return bucket["data"]

    params = {
        "query": query,
        "page": page,
        "include_adult": "false",
        "language": "en-US",
    }
    data = _http_get_json("/search/movie", params)
    results = data.get("results") or []
    out = {
        "page": data.get("page", page),
        "total_pages": data.get("total_pages", 1),
        "items": [_norm_movie(x) for x in results],
    }

    _cache["movie_search"][key] = {"ts": now, "data": out}
    return out


def search_tv(query: str, page: int = 1) -> dict:
    """Search for TV shows by title. Cached per (query, page)."""
    query = query.strip()
    if not query:
        return {"page": page, "total_pages": 0, "items": []}

    page = max(1, int(page))
    now = int(time.time())
    key = (query, page)
    bucket = _cache["tv_search"].get(key)

    if bucket and (now - bucket["ts"]) < CACHE_SECONDS:
        return bucket["data"]

    params = {
        "query": query,
        "page": page,
        "include_adult": "false",
        "language": "en-US",
    }
    data = _http_get_json("/search/tv", params)
    results = data.get("results") or []
    out = {
        "page": data.get("page", page),
        "total_pages": data.get("total_pages", 1),
        "items": [_norm_tv(x) for x in results],
    }

    _cache["tv_search"][key] = {"ts": now, "data": out}
    return out
