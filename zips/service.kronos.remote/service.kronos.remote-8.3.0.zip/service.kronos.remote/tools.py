# -*- coding: utf-8 -*-
# tools.py – with robust power actions
# v4.1.0

from __future__ import annotations
import os
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
VPN_ADDON_ID = "service.vpn.manager"

def _system_exec(cmd: str) -> bool:
    """Execute a system command (safe‑quoted)."""
    try:
        safe = cmd.replace("\\", "\\\\").replace('"', '\\"')
        xbmc.executebuiltin(f'System.Exec("{safe}")')
        return True
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] System exec failed: {e}", xbmc.LOGERROR)
        return False

def vpn_status() -> dict:
    """Check if tun0 exists (VPN up)."""
    is_up = os.path.exists("/sys/class/net/tun0")
    return {"vpn_up": is_up, "iface": "tun0"}

def vpn_reconnect() -> bool:
    """Trigger VPN Manager addon."""
    try:
        xbmc.executebuiltin(f"RunAddon({VPN_ADDON_ID})")
        xbmc.log(f"[{ADDON_ID}] VPN reconnect triggered", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] VPN reconnect failed: {e}", xbmc.LOGERROR)
        return False

def shutdown() -> bool:
    """Shut down the system with fallbacks."""
    # 1. Try Kodi's clean powerdown
    try:
        xbmc.executebuiltin("Powerdown()")
        xbmc.log(f"[{ADDON_ID}] Powerdown executed", xbmc.LOGINFO)
        return True
    except Exception:
        pass

    # 2. Fallback to ShutDown() (capital D)
    try:
        xbmc.executebuiltin("ShutDown()")
        xbmc.log(f"[{ADDON_ID}] ShutDown executed", xbmc.LOGINFO)
        return True
    except Exception:
        pass

    # 3. Last resort – system poweroff (LibreELEC/Linux)
    ok = _system_exec('/bin/sh -c "systemctl poweroff"')
    if ok:
        xbmc.log(f"[{ADDON_ID}] systemctl poweroff executed", xbmc.LOGINFO)
    else:
        xbmc.log(f"[{ADDON_ID}] All shutdown attempts failed", xbmc.LOGERROR)
    return ok

def restart() -> bool:
    """Restart the system with fallbacks."""
    # 1. Try Kodi Reboot()
    try:
        xbmc.executebuiltin("Reboot()")
        xbmc.log(f"[{ADDON_ID}] Reboot executed", xbmc.LOGINFO)
        return True
    except Exception:
        pass

    # 2. System reboot
    ok = _system_exec('/bin/sh -c "systemctl reboot"')
    if ok:
        xbmc.log(f"[{ADDON_ID}] systemctl reboot executed", xbmc.LOGINFO)
    else:
        xbmc.log(f"[{ADDON_ID}] Reboot failed", xbmc.LOGERROR)
    return ok