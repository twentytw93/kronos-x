# -*- coding: utf-8 -*-
# Kronos WG Enforcer - enforcer.py
# v1.5.1 - DHCP EXCEPTION FOR ETHERNET RECONNECTION
#
# v1.5.1 - DHCP EXCEPTION RULES:
# - NEW: _interface_exists() helper – checks if a network interface is present
# - NEW: _interface_has_ip() helper – checks if interface has an IPv4 address
# - NEW: _allow_dhcp() – inserts iptables INPUT/OUTPUT rules for DHCP (ports 67/68)
# - NEW: _remove_dhcp_allow() – removes DHCP allow rules when no longer needed
# - NEW: _dhcp_allowed state flag – tracks whether DHCP exception is active
# - CHANGED: tick() – checks WAN interface presence & IP before VPN logic;
#   allows DHCP when eth is down/no-IP, removes allowance once eth is up
# - BENEFIT: Ethernet can reconnect via DHCP without requiring a full reboot
# - NO other changes: no WiFi auto-detection, no kill-switch cleanup, no extras
#
# v1.5.0 - PRIVACY & IPv6 BLOCKING:
# - PRIVACY: Full IP anonymization (hash ALL IPs in logs, not just public)
# - IPv6: Explicit IPv6 traffic blocking via ip6tables (defense-in-depth)
# - IPv6: DROP all IPv6 INPUT/OUTPUT/FORWARD except loopback
#
# v1.4.1 - SECURITY HARDENING:
# - SECURITY: Replace MD5 with SHA256 for DNS chain hash generation (best practice)
#
# v1.4.0 - SECURITY & PRIVACY HARDENING:
# - REMOVE: Complete IPv6 support removal (IPv4-only enforcement)
# - FIX: Subprocess security (subprocess.run with proper timeouts)
# - FIX: DNS chain collision prevention (PID+CRC32 isolation)
# - FIX: File permissions (0o600 for cache file)
# - PRIVACY: Hash sensitive IPs in logs, sanitize interface names
# - OPT: Cache route table parsing, reduce syscall overhead
# - OPT: Max iteration limits on cleanup loops
#
# v1.3.10:
# - FIX: Remove circular dependency: wg selection must NOT require default route already on wg
# - FIX: Avoid pointless connman reconnect spam when reason == default_not_wg

import os
import glob
import time
import subprocess
import atexit
import hashlib

import xbmc


class WgEnforcer(object):
    def __init__(
        self,
        wireguard_dir,
        wan_if="eth0",
        check_sec=2,
        handshake_max_age_sec=180,
        gw_fallback="192.168.1.1",
        gw_cache_path="/run/kronos_wg_gw.cache",
        log_path="/storage/.kodi/temp/kronos_wg_enforcer.log",
        dns_firewall=False,
        ntp_firewall=None,
        dns_status_log_sec=60,
        dns_chain="KRONOS_CAVE_DNS",
        anonymize_all_ips=True,
    ):
        self.wireguard_dir = wireguard_dir
        self.wan_if = wan_if
        self.check_sec = int(check_sec)
        self.handshake_max_age_sec = int(handshake_max_age_sec)

        self.gw_fallback = gw_fallback
        self.gw_cache_path = gw_cache_path
        self.log_path = log_path

        self.dns_firewall = bool(dns_firewall)
        self.ntp_firewall = bool(ntp_firewall if ntp_firewall is not None else True)
        self._iptables_ok = None
        self._ip6tables_ok = None
        self.anonymize_all_ips = bool(anonymize_all_ips)
        
        # DNS chain isolation: prevent collisions between service instances
        pid = os.getpid()
        chain_seed = (dns_chain or "KRONOS_CAVE_DNS").strip()
        chain_hash = hashlib.sha256(chain_seed.encode('utf-8')).hexdigest()[:8].upper()
        self._dns_chain = "KCV_DNS_%d_%s" % (pid, chain_hash)
        
        self._active_wg_iface = None

        self._dns_status_log_sec = int(dns_status_log_sec) if dns_status_log_sec else 0
        self._last_dns_status_log_ts = 0

        self.profiles = []
        self._profiles_mtime_key = 0

        self._connman_services_cache = (0, "")
        
        # Route table cache (reduce syscall overhead)
        self._route_cache = (0, "")
        self._route_cache_ttl = 1.0

        self._log("init v1.5.1 wireguard_dir=%s wan_if=%s dns_firewall=%s chain=%s dns_status_log_sec=%s anonymize_all_ips=%s" % (
            self.wireguard_dir, self.wan_if, self.dns_firewall, self._dns_chain, self._dns_status_log_sec, self.anonymize_all_ips
        ))

        self._refresh_profiles(force=True)
        
        # Secure cache file permissions
        self._secure_cache_file()

        # DHCP exception state tracking
        self._dhcp_allowed = False

        # CLEANUP FIX: Track registration state
        self._cleanup_registered = False
        self._register_cleanup()

    def _register_cleanup(self):
        """Safely register cleanup with atexit"""
        if not self._cleanup_registered:
            atexit.register(self.cleanup)
            self._cleanup_registered = True

    # ---------------- Logging ----------------

    def _sanitize_ip(self, ip):
        """
        Anonymize IP addresses in logs.
        
        Args:
            ip: IP address to sanitize
        
        Behavior controlled by self.anonymize_all_ips:
            True: Hash ALL IPs except loopback (privacy-first, recommended)
            False: Hash only public IPs (legacy behavior)
        """
        if not ip:
            return "none"
        
        try:
            # PRIVACY-FIRST: anonymize all IPs by default
            if self.anonymize_all_ips:
                # Keep loopback for basic debugging, hash everything else
                if ip.startswith("127."):
                    return ip  # Keep loopback for local debugging
                # Hash all other IPs (both public and private)
                h = hashlib.sha256(ip.encode('utf-8')).hexdigest()[:12]
                return "ip_%s" % h
            
            # Legacy behavior (only for backward compatibility)
            else:
                # Private ranges: keep as-is (less secure)
                if ip.startswith(("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
                                 "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
                                 "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.",
                                 "127.")):
                    return ip
                # Public IPs: hash for privacy
                h = hashlib.sha256(ip.encode('utf-8')).hexdigest()[:12]
                return "pub_%s" % h
                
        except Exception:
            return "invalid"

    def _kodi_log(self, msg, level=xbmc.LOGINFO):
        xbmc.log("[KWG-ENF] %s" % msg, level)

    def _log(self, msg):
        self._kodi_log(msg, xbmc.LOGINFO)
        try:
            if os.path.exists(self.log_path) and os.path.getsize(self.log_path) > 1024 * 1024:
                with open(self.log_path, "w") as f:
                    f.write("Log rotated at %s\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
            with open(self.log_path, "a") as f:
                f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
        except Exception:
            pass

    # ---------------- Process helpers (HARDENED) ----------------

    def _run(self, cmd, timeout=6, ignore_errors=False):
        """Secure subprocess execution with proper timeout and cleanup"""
        # Validate command format and content
        try:
            if not isinstance(cmd, (list, tuple)):
                cmd = [str(cmd)]
            
            # Security: Check each command part for injection attempts
            safe_cmd = []
            for part in cmd:
                part_str = str(part).strip()
                # Basic injection prevention
                if any(c in part_str for c in [';', '|', '&', '$', '`', '\n', '\r', '(']):
                    if not ignore_errors:
                        self._log(f"SECURITY: Rejected unsafe command part: {part_str[:50]}")
                    return 1, "", "unsafe_command"
                safe_cmd.append(part_str)
            
            cmd = safe_cmd
        except Exception as e:
            if not ignore_errors:
                self._log(f"Command validation error: {e}")
            return 1, "", "validation_error"
        
        # REST OF EXISTING METHOD REMAINS UNCHANGED FROM HERE...
        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                check=False
            )
            out = result.stdout.decode("utf-8", "ignore").strip()
            err = result.stderr.decode("utf-8", "ignore").strip()
            rc = result.returncode
            
            if rc != 0 and (not ignore_errors):
                self._log("cmd failed: %s (rc=%d, err=%s)" % (" ".join(cmd), rc, err))
            return rc, out, err
        except subprocess.TimeoutExpired:
            if not ignore_errors:
                self._log("cmd timeout: %s" % " ".join(cmd))
            return 1, "", "timeout"
        except Exception as e:
            if not ignore_errors:
                self._log("cmd exception: %s - %s" % (" ".join(cmd), str(e)))
            return 1, "", str(e)

    # ---------------- Security helpers ----------------

    def _secure_cache_file(self):
        """Ensure cache file has restrictive permissions"""
        try:
            if os.path.exists(self.gw_cache_path):
                os.chmod(self.gw_cache_path, 0o600)
        except Exception:
            pass

    # ---------------- DHCP exception helpers ----------------

    def _interface_exists(self, ifname):
        """Check if the network interface exists"""
        rc, _, _ = self._run(["ip", "link", "show", ifname], timeout=2, ignore_errors=True)
        return rc == 0

    def _interface_has_ip(self, ifname):
        """Check if the interface has an IPv4 address"""
        rc, out, _ = self._run(["ip", "-4", "addr", "show", ifname], timeout=2, ignore_errors=True)
        return rc == 0 and "inet " in out

    def _allow_dhcp(self):
        """Insert iptables rules to permit DHCP client/server communication."""
        if self._dhcp_allowed:
            return
        rules = [
            ["iptables", "-I", "OUTPUT", "1", "-p", "udp", "--sport", "68", "--dport", "67", "-j", "ACCEPT"],
            ["iptables", "-I", "INPUT", "1", "-p", "udp", "--sport", "67", "--dport", "68", "-j", "ACCEPT"],
        ]
        for cmd in rules:
            self._run(cmd, timeout=2, ignore_errors=True)
        self._dhcp_allowed = True
        self._log("DHCP temporarily allowed (interface down)")

    def _remove_dhcp_allow(self):
        """Remove the DHCP allow rules."""
        if not self._dhcp_allowed:
            return
        rules = [
            ["iptables", "-D", "OUTPUT", "-p", "udp", "--sport", "68", "--dport", "67", "-j", "ACCEPT"],
            ["iptables", "-D", "INPUT", "-p", "udp", "--sport", "67", "--dport", "68", "-j", "ACCEPT"],
        ]
        for cmd in rules:
            self._run(cmd, timeout=2, ignore_errors=True)
        self._dhcp_allowed = False
        self._log("DHCP allow rules removed (interface up)")

    # ---------------- Profile parsing ----------------

    def _list_config_files(self):
        if not os.path.isdir(self.wireguard_dir):
            return []
        return sorted(glob.glob(os.path.join(self.wireguard_dir, "*.config")))

    def _profiles_key(self, files):
        mt = 0
        for fp in files:
            try:
                st = os.stat(fp)
                mt = max(mt, int(st.st_mtime))
            except Exception:
                pass
        return (mt << 16) ^ len(files)

    def _parse_provider_config(self, cfg_path):
        name = None
        host = None
        port = None

        try:
            with open(cfg_path, "r") as f:
                for raw in f:
                    line = raw.strip()
                    if not line or line.startswith("#") or line.startswith(";"):
                        continue

                    if line.startswith("Name"):
                        parts = line.split("=", 1)
                        if len(parts) == 2:
                            name = parts[1].strip()

                    elif line.startswith("Host"):
                        parts = line.split("=", 1)
                        if len(parts) == 2:
                            host = parts[1].strip()

                    elif line.startswith("WireGuard.EndpointPort"):
                        parts = line.split("=", 1)
                        if len(parts) == 2:
                            port = parts[1].strip()
        except Exception as e:
            self._log("failed reading config %s: %s" % (cfg_path, e))
            return None

        if not host:
            return None

        return {"path": cfg_path, "name": name or "", "host": host, "port": port or ""}

    def _refresh_profiles(self, force=False):
        files = self._list_config_files()
        key = self._profiles_key(files)

        if (not force) and key == self._profiles_mtime_key:
            return

        self._profiles_mtime_key = key
        profs = []
        for fp in files:
            p = self._parse_provider_config(fp)
            if p:
                profs.append(p)

        self.profiles = profs
        self._log("profiles loaded: %d" % len(self.profiles))

    # ---------------- Routing helpers (IPv4-ONLY) ----------------

    def _get_route_table(self):
        """Cached route table retrieval with fast /proc path for Pi 5"""
        now = time.time()
        ts, cached = self._route_cache
        
        if (now - ts) < self._route_cache_ttl and cached:
            return cached
        
        # PERFORMANCE FIX: Try fast /proc reading first for Pi 5
        try:
            with open('/proc/net/route', 'r') as f:
                proc_content = f.read()
            # Convert /proc format to compatible ip-route format
            # Keep minimal conversion for backward compatibility
            if proc_content:
                # Parse and convert to standard format
                lines = []
                for line in proc_content.splitlines():
                    if not line.strip() or line.startswith('Iface'):
                        continue
                    parts = line.split()
                    if len(parts) >= 8:
                        iface = parts[0]
                        dest = parts[1]
                        gateway = parts[2]
                        # Convert hex IP to dotted decimal
                        if dest == '00000000' and gateway != '00000000':
                            # Default route found
                            # FIX: Proper hex IP conversion (little-endian to dotted decimal)
                            # Gateway hex string is 8 characters like "0101A8C0" = 192.168.1.1
                            gate_bytes = [gateway[i:i+2] for i in (6, 4, 2, 0)]
                            gate_ip = '.'.join(str(int(byte, 16)) for byte in gate_bytes)
                            lines.append(f"default via {gate_ip} dev {iface}")
                if lines:
                    result = '\n'.join(lines)
                    self._route_cache = (now, result)
                    return result
        except Exception:
            pass  # Fall back to ip command
        
        # Fallback to original ip command method
        rc, out, _ = self._run(["ip", "-4", "route"], timeout=3)
        if rc == 0 and out:
            self._route_cache = (now, out)
            return out
        
        return ""

    def _get_eth_gw(self):
        """Extract IPv4 gateway for WAN interface"""
        out = self._get_route_table()
        if out:
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("default ") and (" dev %s" % self.wan_if) in line and " via " in line:
                    parts = line.split()
                    if "via" in parts:
                        gw = parts[parts.index("via") + 1]
                        try:
                            with open(self.gw_cache_path, "w") as f:
                                f.write(gw)
                            self._secure_cache_file()
                        except Exception:
                            pass
                        return gw

        # Fallback to cached value
        try:
            if os.path.exists(self.gw_cache_path):
                with open(self.gw_cache_path, "r") as f:
                    gw = f.read().strip()
                    if gw:
                        return gw
        except Exception:
            pass

        return self.gw_fallback

    def _ensure_endpoint_routes(self):
        """Pin VPN endpoint routes via WAN (prevent routing loop)"""
        gw = self._get_eth_gw()
        for p in self.profiles:
            host = p.get("host", "")
            if not host:
                continue
            # IPv4 only: /32 host route
            self._run(["ip", "-4", "route", "replace", "%s/32" % host, "via", gw, "dev", self.wan_if], timeout=3)

    def _default_route_line(self):
        """Get current default route (IPv4 only)"""
        out = self._get_route_table()
        if not out:
            return ""

        blackhole = ""
        default = ""
        for line in out.splitlines():
            ln = line.strip()
            if ln.startswith("blackhole default"):
                blackhole = ln
            elif ln.startswith("default "):
                default = ln

        # Prefer real default when both exist (prevents false "vpn down")
        return default or blackhole or ""

    def _purge_default_routes(self, keep_dev=None, keep_blackhole=False):
        """
        Ensure we don't end up with multiple defaults (IPv4 only):
          - keep_dev: if set, keep ONLY "default ..." routes on that dev
          - keep_blackhole: if True, keep blackhole default (otherwise delete it)
        """
        rc, out, _ = self._run(["ip", "-4", "route", "show", "default"], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return

        # SAFETY: Split once into list, iterate fixed number of times
        lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
        
        for line in lines:
            if not line:
                continue

            if line.startswith("blackhole default"):
                if keep_blackhole:
                    continue
                self._run(["ip", "-4", "route", "del", "blackhole", "default"], timeout=3, ignore_errors=True)
                continue

            if not line.startswith("default "):
                continue

            toks = line.split()
            via = None
            dev = None
            for i, t in enumerate(toks):
                if t == "via" and (i + 1) < len(toks):
                    via = toks[i + 1]
                elif t == "dev" and (i + 1) < len(toks):
                    dev = toks[i + 1]

            if keep_dev and dev == keep_dev:
                continue

            cmd = ["ip", "-4", "route", "del", "default"]
            if via:
                cmd += ["via", via]
            if dev:
                cmd += ["dev", dev]
            self._run(cmd, timeout=3, ignore_errors=True)

    def _set_default_blackhole(self):
        """Set IPv4 blackhole default (kill-switch)"""
        self._purge_default_routes(keep_dev=None, keep_blackhole=False)
        self._run(["ip", "-4", "route", "replace", "blackhole", "default"], timeout=3)

    def _set_default_dev(self, dev):
        """Set IPv4 default route via WireGuard interface"""
        self._purge_default_routes(keep_dev=dev, keep_blackhole=False)
        self._run(["ip", "-4", "route", "replace", "default", "dev", dev], timeout=3)

    # ---------------- DNS route pinning (IPv4-ONLY) ----------------

    def _is_ipv4(self, s):
        """Validate IPv4 address format"""
        try:
            if not s or ":" in s:  # Reject IPv6
                return False
            parts = s.split(".")
            if len(parts) != 4:
                return False
            for p in parts:
                if p == "":
                    return False
                n = int(p)
                if n < 0 or n > 255:
                    return False
            return True
        except Exception:
            return False

    def _read_connman_nameservers(self):
        """Read IPv4 nameservers only"""
        servers = []
        path = "/run/connman/resolv.conf"
        try:
            if not os.path.exists(path):
                return servers
            with open(path, "r") as f:
                for raw in f:
                    line = raw.strip()
                    if not line.startswith("nameserver "):
                        continue
                    ip = line.split(None, 1)[1].strip()
                    # Only accept IPv4 addresses
                    if ip and self._is_ipv4(ip) and ip not in servers:
                        servers.append(ip)
        except Exception:
            pass
        return servers

    def _pin_dns_server_routes(self, wg_iface):
        """
        Prevent ConnMan DNS "flaps" by (IPv4 only):
          - removing any DNS host route via eth0 (leak path)
          - ensuring DNS host route via wg iface when wg is up
        """
        servers = self._read_connman_nameservers()
        if not servers:
            return

        for ip in servers:
            if not self._is_ipv4(ip):
                continue

            # Delete any eth0 route to this DNS server (avoid leak / flap)
            rc, out, _ = self._run(["ip", "-4", "route", "show", ip], timeout=3, ignore_errors=True)
            if rc == 0 and out:
                for raw in out.splitlines():
                    ln = raw.strip()
                    if not ln:
                        continue
                    if (" dev %s" % self.wan_if) not in ln:
                        continue

                    toks = ln.split()
                    dst = toks[0] if toks else ip
                    via = None
                    dev = None
                    for i, t in enumerate(toks):
                        if t == "via" and (i + 1) < len(toks):
                            via = toks[i + 1]
                        elif t == "dev" and (i + 1) < len(toks):
                            dev = toks[i + 1]

                    if dev == self.wan_if:
                        cmd = ["ip", "-4", "route", "del", dst]
                        if via:
                            cmd += ["via", via]
                        cmd += ["dev", dev]
                        self._run(cmd, timeout=3, ignore_errors=True)

            # Ensure route via wg iface when up (IPv4 only)
            if wg_iface:
                self._run(["ip", "-4", "route", "replace", ip, "dev", wg_iface], timeout=3, ignore_errors=True)

    # ---------------- WireGuard state (IPv4-ONLY) ----------------

    def _wg_tool_available(self):
        rc, _, _ = self._run(["wg", "show", "interfaces"], timeout=3, ignore_errors=True)
        return rc == 0

    def _wg_interfaces(self):
        rc, out, _ = self._run(["wg", "show", "interfaces"], timeout=3, ignore_errors=True)
        if rc == 0 and out:
            return [x.strip() for x in out.split() if x.strip()]
        return []

    def _link_is_up(self, ifname):
        rc, out, _ = self._run(["ip", "link", "show", ifname], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return False
        return ("<" in out and ",UP," in out) or (" state UP" in out)

    def _interface_has_vpn_ip(self, ifname):
        """Check for valid IPv4 VPN address (not link-local/loopback)"""
        rc, out, _ = self._run(["ip", "-4", "addr", "show", ifname], timeout=3, ignore_errors=True)
        if rc != 0:
            return False

        for line in out.splitlines():
            if "inet " not in line:
                continue
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            ip_cidr = parts[1]
            ip = ip_cidr.split('/')[0]
            # Reject link-local and loopback
            if not ip.startswith("169.254.") and not ip.startswith("127."):
                return True
        return False

    def _pick_active_wg(self):
        """
        Pick a *candidate* WG interface based on (IPv4 only):
          1) wg tool reports it
          2) interface link UP
          3) has a real VPN IPv4 address

        DO NOT require default route here (tick() must be able to set it).
        """
        candidates = self._wg_interfaces()
        if not candidates:
            return None

        for ifn in sorted(set(candidates)):
            if not self._link_is_up(ifn):
                self._log("WG interface %s not UP" % ifn)
                continue
            if not self._interface_has_vpn_ip(ifn):
                self._log("WG interface %s has no VPN IP" % ifn)
                continue
            return ifn

        return None

    def _latest_handshake_age(self, ifname):
        if not self._wg_tool_available():
            return None

        rc, out, _ = self._run(["wg", "show", ifname, "latest-handshakes"], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return None

        now = int(time.time())
        best = 0
        for raw in out.splitlines():
            ln = raw.strip()
            if not ln:
                continue
            parts = ln.split()
            if len(parts) < 2:
                continue
            try:
                ts = int(parts[1])
                if ts > best:
                    best = ts
            except Exception:
                pass

        if best <= 0:
            return None

        age = now - best
        if age < 0:
            age = 0
        return age

    # ---------------- ConnMan helpers ----------------

    def _connman_services(self):
        now = int(time.time())
        ts, cached = self._connman_services_cache

        if (now - ts) > 10:
            cached = ""

        if (now - ts) < 3 and cached:
            return cached

        rc, out, _ = self._run(["connmanctl", "services"], timeout=6, ignore_errors=True)
        if rc != 0:
            out = ""
        self._connman_services_cache = (now, out)
        return out

    def _vpn_service_ids(self):
        out = self._connman_services()
        ids = []
        if not out:
            return ids
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            last = line.split()[-1]
            if last.startswith("vpn_"):
                ids.append(last)
        return sorted(set(ids))

    def _connect_all_vpns(self):
        ids = self._vpn_service_ids()
        for sid in ids:
            self._run(["connmanctl", "connect", sid], timeout=10, ignore_errors=True)

    # ---------------- DNS firewall (iptables IPv4-ONLY) ----------------

    def _iptables_available(self):
        if self._iptables_ok is not None:
            return self._iptables_ok
        rc, _, _ = self._run(["iptables", "-V"], timeout=3, ignore_errors=True)
        self._iptables_ok = (rc == 0)
        if not self._iptables_ok:
            self._log("iptables not available; DNS firewall disabled")
        return self._iptables_ok

    def _ip6tables_available(self):
        """Check if ip6tables is available for IPv6 blocking"""
        if self._ip6tables_ok is not None:
            return self._ip6tables_ok
        rc, _, _ = self._run(["ip6tables", "-V"], timeout=3, ignore_errors=True)
        self._ip6tables_ok = (rc == 0)
        if not self._ip6tables_ok:
            self._log("ip6tables not available; IPv6 blocking limited")
        return self._ip6tables_ok

    def _block_ipv6_traffic(self):
        """Block all IPv6 traffic (defense-in-depth)"""
        if not self._ip6tables_available():
            return
        
        # STATE CHECK: Verify if IPv6 is already blocked
        # Check INPUT chain policy
        rc_input, out_input, _ = self._run(["ip6tables", "-L", "INPUT", "-n"], timeout=2, ignore_errors=True)
        # Check OUTPUT chain policy  
        rc_output, out_output, _ = self._run(["ip6tables", "-L", "OUTPUT", "-n"], timeout=2, ignore_errors=True)
        
        # EFFICIENCY: Skip if already blocked (reduces system calls)
        if (rc_input == 0 and "Chain INPUT (policy DROP)" in out_input and
            rc_output == 0 and "Chain OUTPUT (policy DROP)" in out_output):
            # Already blocked, skip redundant operations
            return
        
        # Apply blocking rules only if needed
        rules = [
            ["ip6tables", "-P", "INPUT", "DROP"],
            ["ip6tables", "-P", "FORWARD", "DROP"],
            ["ip6tables", "-P", "OUTPUT", "DROP"],
            ["ip6tables", "-A", "INPUT", "-i", "lo", "-j", "ACCEPT"],
            ["ip6tables", "-A", "OUTPUT", "-o", "lo", "-j", "ACCEPT"],
        ]
        
        for cmd in rules:
            self._run(cmd, timeout=3, ignore_errors=True)
        
        # VERIFICATION: Log confirmation IPv6 blocking is active
        self._log("IPv6 traffic blocked (defense-in-depth)")
        
        # Add verification step (once)
        if not hasattr(self, '_ipv6_verified'):
            self._verify_ipv6_blocking()

    def _verify_ipv6_blocking(self):
        """Verify IPv6 blocking is active (one-time check)"""
        rc_input, out_input, _ = self._run(["ip6tables", "-L", "INPUT", "-n"], timeout=2, ignore_errors=True)
        rc_output, out_output, _ = self._run(["ip6tables", "-L", "OUTPUT", "-n"], timeout=2, ignore_errors=True)
        
        input_ok = rc_input == 0 and "Chain INPUT (policy DROP)" in out_input
        output_ok = rc_output == 0 and "Chain OUTPUT (policy DROP)" in out_output
        
        if input_ok and output_ok:
            self._log("✅ IPv6 blocking verified active")
        else:
            self._log("⚠ IPv6 blocking verification failed")
        
        self._ipv6_verified = True


    def _unblock_ipv6_traffic(self):
        """Restore IPv6 traffic (cleanup)"""
        if not self._ip6tables_available():
            return
        
        # Restore default policies
        rules = [
            ["ip6tables", "-P", "INPUT", "ACCEPT"],
            ["ip6tables", "-P", "FORWARD", "ACCEPT"],
            ["ip6tables", "-P", "OUTPUT", "ACCEPT"],
            ["ip6tables", "-F"],  # Flush all rules
        ]
        
        for cmd in rules:
            self._run(cmd, timeout=3, ignore_errors=True)
        
        self._log("IPv6 blocking removed")

    def _iptables_ensure_chain(self):
        self._run(["iptables", "-N", self._dns_chain], timeout=3, ignore_errors=True)

    def _iptables_hook_count(self):
        rc, out, _ = self._run(["iptables", "-S", "OUTPUT"], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return 0
        target = "-A OUTPUT -j %s" % self._dns_chain
        return sum(1 for ln in out.splitlines() if ln.strip() == target)

    def _iptables_ensure_hook_dedup(self):
        """Ensure single OUTPUT hook with iteration limit"""
        rc, _, _ = self._run(["iptables", "-C", "OUTPUT", "-j", self._dns_chain], timeout=3, ignore_errors=True)
        if rc != 0:
            self._run(["iptables", "-I", "OUTPUT", "1", "-j", self._dns_chain], timeout=3, ignore_errors=True)

        # Limit iterations to prevent infinite loops
        max_iterations = 10
        iteration = 0
        while iteration < max_iterations:
            iteration += 1
            cnt = self._iptables_hook_count()
            if cnt <= 1:
                break
            self._run(["iptables", "-D", "OUTPUT", "-j", self._dns_chain], timeout=3, ignore_errors=True)

    def _dns_drop_rules_ensure(self):
        """Ensure DNS DROP rules exist (IPv4 only)"""
        rc, _, _ = self._run(["iptables", "-C", self._dns_chain, "-p", "udp", "--dport", "53", "-j", "DROP"], timeout=3, ignore_errors=True)
        if rc != 0:
            self._run(["iptables", "-A", self._dns_chain, "-p", "udp", "--dport", "53", "-j", "DROP"], timeout=3, ignore_errors=True)

        rc, _, _ = self._run(["iptables", "-C", self._dns_chain, "-p", "tcp", "--dport", "53", "-j", "DROP"], timeout=3, ignore_errors=True)
        if rc != 0:
            self._run(["iptables", "-A", self._dns_chain, "-p", "tcp", "--dport", "53", "-j", "DROP"], timeout=3, ignore_errors=True)

    def _dns_accept_rules_present(self, wg_iface):
        if not wg_iface:
            return False
        rc1, _, _ = self._run(["iptables", "-C", self._dns_chain, "-p", "udp", "--dport", "53", "-o", wg_iface, "-j", "ACCEPT"], timeout=3, ignore_errors=True)
        rc2, _, _ = self._run(["iptables", "-C", self._dns_chain, "-p", "tcp", "--dport", "53", "-o", wg_iface, "-j", "ACCEPT"], timeout=3, ignore_errors=True)
        return (rc1 == 0 and rc2 == 0)

    def _dns_any_accept_rules_present(self):
        rc, out, _ = self._run(["iptables", "-S", self._dns_chain], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return False
        for ln in out.splitlines():
            s = ln.strip()
            if not s.startswith("-A "):
                continue
            if " -j ACCEPT" not in s:
                continue
            if " --dport 53" not in s:
                continue
            if (" -p udp" in s) or (" -p tcp" in s):
                return True
        return False

    def _dns_accept_rules_clear(self):
        """Clear DNS ACCEPT rules with iteration limit"""
        rc, out, _ = self._run(["iptables", "-S", self._dns_chain], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return

        lines = [x.strip() for x in out.splitlines() if x.strip().startswith("-A ")]
        
        # Limit iterations to prevent infinite loops
        max_iterations = 50
        iteration = 0
        
        for line in lines:
            if iteration >= max_iterations:
                self._log("WARNING: dns_accept_rules_clear hit max iterations")
                break
            iteration += 1
            
            if " -j ACCEPT" not in line:
                continue
            if " --dport 53" not in line:
                continue
            if (" -p udp" not in line) and (" -p tcp" not in line):
                continue

            parts = line.split()
            parts[0] = "-D"
            cmd = ["iptables"] + parts
            self._run(cmd, timeout=3, ignore_errors=True)

    def _dns_firewall_apply(self, wg_iface):
        """Apply DNS firewall rules (IPv4 only)"""
        if not self.dns_firewall:
            return
        if not self._iptables_available():
            return

        self._iptables_ensure_chain()
        self._dns_drop_rules_ensure()
        self._iptables_ensure_hook_dedup()

        desired = wg_iface if wg_iface else None

        need_update = False
        if desired != self._active_wg_iface:
            need_update = True
        else:
            if desired:
                if not self._dns_accept_rules_present(desired):
                    need_update = True
            else:
                if self._dns_any_accept_rules_present():
                    need_update = True

        if need_update:
            self._dns_accept_rules_clear()

            if desired:
                self._run(["iptables", "-I", self._dns_chain, "1", "-p", "udp", "--dport", "53", "-o", desired, "-j", "ACCEPT"], timeout=3, ignore_errors=True)
                self._run(["iptables", "-I", self._dns_chain, "1", "-p", "tcp", "--dport", "53", "-o", desired, "-j", "ACCEPT"], timeout=3, ignore_errors=True)
                self._active_wg_iface = desired
            else:
                self._active_wg_iface = None

        self._dns_firewall_status_log_maybe()

    def _dns_firewall_status(self):
        if not self.dns_firewall:
            return "disabled"
        if not self._iptables_available():
            return "iptables_missing"

        rc, out, _ = self._run(["iptables", "-L", self._dns_chain, "-n", "-v"], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return "chain_not_found"

        accept = out.count("ACCEPT")
        drop = out.count("DROP")
        return "active: %d ACCEPT, %d DROP (wg=%s)" % (accept, drop, (self._active_wg_iface or "none"))

    def _dns_firewall_status_log_maybe(self):
        if not self._dns_status_log_sec or self._dns_status_log_sec <= 0:
            return
        now = int(time.time())
        if (now - self._last_dns_status_log_ts) < self._dns_status_log_sec:
            return
        self._last_dns_status_log_ts = now
        self._log("DNS firewall: %s" % self._dns_firewall_status())

    def _dns_firewall_clear(self):
        """Clear DNS firewall with iteration limit"""
        if not self.dns_firewall:
            return
        if not self._iptables_available():
            return

        # Clear NTP DROP rule if it exists
        self._run(["iptables", "-D", self._dns_chain, "-p", "udp", "--dport", "123", "-j", "DROP"], timeout=3, ignore_errors=True)

        # Limit iterations to prevent infinite loops
        max_iterations = 20
        iteration = 0
        while iteration < max_iterations:
            iteration += 1
            rc, _, _ = self._run(["iptables", "-D", "OUTPUT", "-j", self._dns_chain], timeout=3, ignore_errors=True)
            if rc != 0:
                break

        self._run(["iptables", "-F", self._dns_chain], timeout=3, ignore_errors=True)
        self._run(["iptables", "-X", self._dns_chain], timeout=3, ignore_errors=True)
        self._active_wg_iface = None

    # ---------------- NTP firewall (iptables IPv4-ONLY) ----------------

    def _ntp_drop_rules_ensure(self):
        """Ensure NTP DROP rule exists (IPv4 only)"""
        rc, _, _ = self._run(["iptables", "-C", self._dns_chain, "-p", "udp", "--dport", "123", "-j", "DROP"], timeout=3, ignore_errors=True)
        if rc != 0:
            self._run(["iptables", "-A", self._dns_chain, "-p", "udp", "--dport", "123", "-j", "DROP"], timeout=3, ignore_errors=True)

    def _ntp_accept_rules_present(self, wg_iface):
        """Check if NTP ACCEPT rule exists for given wg interface"""
        if not wg_iface:
            return False
        rc, _, _ = self._run(["iptables", "-C", self._dns_chain, "-p", "udp", "--dport", "123", "-o", wg_iface, "-j", "ACCEPT"], timeout=3, ignore_errors=True)
        return (rc == 0)

    def _ntp_any_accept_rules_present(self):
        """Check if any NTP ACCEPT rules exist"""
        rc, out, _ = self._run(["iptables", "-S", self._dns_chain], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return False
        for ln in out.splitlines():
            s = ln.strip()
            if not s.startswith("-A "):
                continue
            if " -j ACCEPT" not in s:
                continue
            if " --dport 123" not in s:
                continue
            if " -p udp" in s:
                return True
        return False

    def _ntp_accept_rules_clear(self):
        """Clear NTP ACCEPT rules with iteration limit"""
        rc, out, _ = self._run(["iptables", "-S", self._dns_chain], timeout=3, ignore_errors=True)
        if rc != 0 or not out:
            return

        lines = [x.strip() for x in out.splitlines() if x.strip().startswith("-A ")]
        
        # Limit iterations to prevent infinite loops
        max_iterations = 50
        iteration = 0
        
        for line in lines:
            if iteration >= max_iterations:
                self._log("WARNING: ntp_accept_rules_clear hit max iterations")
                break
            iteration += 1
            
            if " -j ACCEPT" not in line:
                continue
            if " --dport 123" not in line:
                continue
            if " -p udp" not in line:
                continue

            parts = line.split()
            parts[0] = "-D"
            cmd = ["iptables"] + parts
            self._run(cmd, timeout=3, ignore_errors=True)

    def _ntp_firewall_apply(self, wg_iface):
        """Apply NTP firewall rules (IPv4 only)"""
        if not self.ntp_firewall:
            return
        if not self._iptables_available():
            return

        # Ensure chain and DROP rule exist
        self._iptables_ensure_chain()
        self._ntp_drop_rules_ensure()

        desired = wg_iface if wg_iface else None

        need_update = False
        if desired:
            if not self._ntp_accept_rules_present(desired):
                need_update = True
        else:
            if self._ntp_any_accept_rules_present():
                need_update = True

        if need_update:
            self._ntp_accept_rules_clear()

            if desired:
                # Insert ACCEPT rule before DROP rule
                self._run(["iptables", "-I", self._dns_chain, "1", "-p", "udp", "--dport", "123", "-o", desired, "-j", "ACCEPT"], timeout=3, ignore_errors=True)

    def _ntp_firewall_clear(self):
        """Clear NTP firewall rules"""
        if not self.ntp_firewall:
            return
        if not self._iptables_available():
            return

        self._ntp_accept_rules_clear()
        
        # Remove DROP rule
        self._run(["iptables", "-D", self._dns_chain, "-p", "udp", "--dport", "123", "-j", "DROP"], timeout=3, ignore_errors=True)

    def security_status(self):
        ok, wgif, reason = self.vpn_ok()
        status = {
            "vpn_ok": bool(ok),
            "wg": wgif,
            "reason": reason,
            "dns_firewall": bool(self.dns_firewall),
            "active_wg_iface": self._active_wg_iface,
            "default_route": self._default_route_line(),
            "profiles_loaded": int(len(self.profiles)),
            "iptables_available": bool(self._iptables_ok) if self._iptables_ok is not None else None,
        }
        if self.dns_firewall:
            status["dns_status"] = self._dns_firewall_status()
        return status

    # ---------------- Public: VPN health ----------------

    def vpn_ok(self):
        wg = self._pick_active_wg()
        if not wg:
            return False, None, "no_wg_up"

        d = self._default_route_line()
        if (" dev %s" % wg) not in d:
            return False, wg, "default_not_wg"

        if self.handshake_max_age_sec > 0:
            age = self._latest_handshake_age(wg)
            if age is None:
                return True, wg, "ok_no_handshake_info"
            if age > self.handshake_max_age_sec:
                return False, wg, "handshake_stale_%ss" % age

        return True, wg, "ok"

    # ---------------- Public: main tick ----------------

    def tick(self):
        # Invalidate route cache for fresh data
        self._route_cache = (0, "")

        # ---------- Interface presence & IP check ----------
        if (not self._interface_exists(self.wan_if) or
                not self._interface_has_ip(self.wan_if)):
            # Interface is down or has no IP – allow DHCP, skip VPN logic
            self._allow_dhcp()
            self._log("Interface %s down or no IP – allowing DHCP" % self.wan_if)
            return {"vpn_ok": False, "wg": None, "reason": "wan_interface_down"}

        # Interface has IP – remove DHCP allowance
        self._remove_dhcp_allow()

        # ---------- Normal enforcer logic (unchanged from v1.5.0) ----------
        self._refresh_profiles(force=False)
        self._ensure_endpoint_routes()

        ok, _, reason = self.vpn_ok()
        if not ok and reason != "default_not_wg":
            self._connect_all_vpns()

        wg = self._pick_active_wg()

        if wg:
            d = self._default_route_line()
            if (" dev %s" % wg) not in d:
                self._log("forcing default -> %s (was: %s)" % (wg, d or "<none>"))
                self._set_default_dev(wg)
            else:
                self._purge_default_routes(keep_dev=wg, keep_blackhole=False)
        else:
            d = self._default_route_line()
            if "blackhole default" not in d:
                self._log("no wg interface UP -> blackhole default (was: %s)" % (d or "<none>"))
                self._set_default_blackhole()
            else:
                self._purge_default_routes(keep_dev=None, keep_blackhole=True)

        self._pin_dns_server_routes(wg)

        if self.dns_firewall:
            self._dns_firewall_apply(wg)
            self._ntp_firewall_apply(wg)
            self._block_ipv6_traffic()

        ok, wgif, reason = self.vpn_ok()
        return {"vpn_ok": ok, "wg": wgif, "reason": reason}

    def cleanup(self):
        """Robust cleanup with registration tracking"""
        # Unregister first to prevent duplicate calls
        if self._cleanup_registered:
            try:
                atexit.unregister(self.cleanup)
            except Exception:
                pass
            self._cleanup_registered = False
        
        self._log("cleanup: start")
        try:
            if self.dns_firewall:
                self._ntp_firewall_clear()
                self._dns_firewall_clear()
                self._unblock_ipv6_traffic()
        except Exception as e:
            self._log("cleanup error: %s" % str(e))
        self._log("cleanup: done")

    def __del__(self):
        try:
            self.cleanup()
        except Exception:
            pass
