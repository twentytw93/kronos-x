# -*- coding: utf-8 -*-
# Kronos WG Enforcer - service.py
# v1.5.0 - PRIVACY & IPv6 HARDENING
#
# LibreELEC / Kodi 21.x
# - Enforces routing via wg* (IPv4 only)
# - Blackholes default when wg is down (no leak)
# - Kill-switch: stops NON-LAN playback if VPN not OK (LAN/local stays allowed)
# - NTP PROTECTION: Firewall-based NTP leak prevention (allows time sync via VPN only)
# - PRIVACY: Full IP anonymization in logs (all IPs hashed)
# - IPv6: Explicit IPv6 blocking via ip6tables (defense-in-depth)
#
# v1.5.0 - PRIVACY & IPv6 BLOCKING:
# - PRIVACY: Full IP anonymization (hash ALL IPs in logs, not just public)
# - IPv6: Explicit IPv6 traffic blocking via ip6tables (defense-in-depth)
#
# v1.4.1 - NTP FIREWALL PROTECTION:
# - ADD: Firewall-based NTP leak prevention (iptables rules in enforcer.py)
# - ALLOW: Time sync via VPN only, block NTP on WAN interface
# - LOG: NTP firewall status logging in enforcer
# - PERSISTENT: Rules reapplied on network changes
#
# v1.4.0 - SECURITY & PRIVACY HARDENING:
# - REMOVE: Complete IPv6 support removal (IPv4-only)
# - PRIVACY: Change ping host from 1.1.1.1 to 9.9.9.9 (Quad9)
# - FIX: Use subprocess.run instead of Popen for ping (proper cleanup)
# - FIX: Input validation for hostname parsing
# - OPT: Reduce ping frequency when idle
#
# v1.3.5:
# - ADD: Dead-tunnel detection (wg looks up but traffic is dead):
#        Periodic ping via active wg iface; on consecutive failures -> trigger ConnMan reconnect
#        and treat VPN as down for kill-switch decisions.

import os
import sys
import time
import re
import zlib
import subprocess
from urllib.parse import urlsplit

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui


# Resolve addon path reliably on Kodi 21
_ADDON = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo("id") or "kronos.cave"
_ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo("path"))
_LIB_PATH = os.path.join(_ADDON_PATH, "resources", "lib")
if _LIB_PATH not in sys.path:
    sys.path.insert(0, _LIB_PATH)

from enforcer import WgEnforcer  # noqa: E402


def _log(msg):
    xbmc.log("[KWG-CAVE] %s" % msg, xbmc.LOGINFO)


def _disable_ntp_services():
    """
    Permanently disable all NTP services to eliminate time synchronization IP leaks.
    Uses systemctl mask to prevent services from starting via any trigger (boot, manual, network).
    This is a one-time system hardening step that runs when the VPN service starts.
    """
    _log("Starting NTP leak protection hardening...")
    
    # List of all common NTP/time synchronization services to disable
    ntp_services = [
        "systemd-timesyncd",  # systemd's built-in NTP client (most common)
        "chronyd",            # Chrony NTP daemon
        "ntpd",               # Traditional NTP daemon
        "ntpdate",            # NTP date setting service
        "openntpd",           # OpenNTPD daemon
        "ntp",                # Generic NTP service name
        "timedatex",          # Alternative timing service
    ]
    
    disabled_count = 0
    failed_count = 0
    
    for service in ntp_services:
        try:
            # First, stop the service if it's running
            stop_cmd = ["systemctl", "stop", service]
            stop_result = subprocess.run(
                stop_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5.0,
                check=False
            )
            
            # Then mask it to prevent it from ever starting again
            mask_cmd = ["systemctl", "mask", service]
            mask_result = subprocess.run(
                mask_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5.0,
                check=False
            )
            
            # Check if masking was successful (return code 0)
            if mask_result.returncode == 0:
                _log(f"✓ Permanently disabled NTP service: {service}")
                disabled_count += 1
            else:
                # Service might not exist or already be masked
                stderr = mask_result.stderr.decode('utf-8', errors='ignore').strip()
                if "not found" in stderr or "No such file" in stderr:
                    _log(f"ℹ NTP service not installed: {service}")
                elif "already masked" in stderr:
                    _log(f"✓ NTP service already masked: {service}")
                    disabled_count += 1
                else:
                    _log(f"✗ Failed to mask {service}: {stderr}")
                    failed_count += 1
                    
        except subprocess.TimeoutExpired:
            _log(f"⚠ Timeout while disabling {service}, continuing...")
            failed_count += 1
        except Exception as e:
            _log(f"✗ Error disabling {service}: {str(e)}")
            failed_count += 1
    
    # Also disable any socket activations for NTP services
    ntp_sockets = [
        "systemd-timesyncd.socket",
        "chronyd.socket",
        "ntpd.socket",
    ]
    
    for socket in ntp_sockets:
        try:
            mask_cmd = ["systemctl", "mask", socket]
            subprocess.run(
                mask_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5.0,
                check=False
            )
            _log(f"✓ Disabled NTP socket activation: {socket}")
        except Exception:
            pass  # Silently continue if socket doesn't exist
    
    # Final status report
    if disabled_count > 0:
        _log(f"NTP hardening complete: {disabled_count} services permanently disabled")
    if failed_count > 0:
        _log(f"NTP hardening: {failed_count} services failed to disable (may not be installed)")
    
    # Verify the system is protected
    try:
        # Check if systemd-timesyncd (most common) is properly masked
        check_cmd = ["systemctl", "is-enabled", "systemd-timesyncd"]
        check_result = subprocess.run(
            check_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=3.0,
            check=False
        )
        
        stdout = check_result.stdout.decode('utf-8', errors='ignore').strip()
        if "masked" in stdout or check_result.returncode != 0:
            _log("✅ NTP leak protection: System is hardened against time sync IP leaks")
        else:
            _log("⚠ NTP leak protection: System may still be vulnerable to time sync leaks")
    except Exception:
        _log("ℹ NTP status check completed (some checks may have failed)")


# IPv4 private ranges (IPv6 removed)
_PRIVATE_172_RE = re.compile(r"^172\.(1[6-9]|2[0-9]|3[0-1])\.")


def _dns_chain_for_addon(addon_id):
    """Generate unique DNS chain name for this addon instance"""
    try:
        h = zlib.crc32((addon_id or "").encode("utf-8")) & 0xFFFFFFFF
    except Exception:
        h = 0
    return "KCV_DNS_%08X" % h


def _is_private_host(host):
    """Check if hostname is private/local (IPv4 only, IPv6 removed)"""
    try:
        host = str(host).strip().lower()
    except Exception:
        return False
    
    if not host:
        return False

    # Basic hostname validation (prevent injection)
    if len(host) > 253:  # Max DNS hostname length
        return False
    if host.startswith('-') or host.endswith('-'):
        return False

    if host == "localhost":
        return True

    # IPv4 private ranges only (IPv6 removed)
    if host.startswith("10."):
        return True
    if host.startswith("192.168."):
        return True
    if _PRIVATE_172_RE.match(host):
        return True

    # Zeroconf / LAN domains
    if host.endswith(".local"):
        return True

    # Single-label hostnames are typically LAN (e.g. http://nas/ , http://kronos-x/)
    if "." not in host:
        return True

    return False


def _is_lan_or_local_playback(url):
    """
    True -> allow playback even if VPN is down
    False -> treat as non-LAN (kill when VPN is down)
    """
    try:
        p = str(url).strip()
    except Exception:
        return False

    if not p:
        return False

    pl = p.lower()

    # Always allow local/LAN schemes/paths
    allow_prefixes = (
        "smb://",
        "nfs://",
        "upnp://",
        "special://",
        "storage://",
        "stack://",
        "rar://",
        "zip://",
        "bluray://",
        "dvd://",
        "udf://",
        "file://",
        "/storage/",
        "/var/media/",
    )
    if pl.startswith(allow_prefixes):
        return True

    # For http(s), allow only private IPs / local hostnames (IPv4 only, IPv6 removed)
    if pl.startswith("http://") or pl.startswith("https://"):
        try:
            u = urlsplit(pl)
            host = (u.hostname or "").strip().lower()
        except Exception:
            host = ""
        return _is_private_host(host)

    return False


def _should_kill_when_vpn_down(player):
    """
    Kill when VPN is down for:
    - plugin:// (streaming addons)
    - http(s) public hosts
    - unknown schemes (safe default)
    Allow:
    - LAN/local sources
    """
    try:
        p = player.getPlayingFile() or ""
    except Exception:
        return True

    pl = p.strip().lower()
    if not pl:
        return True

    if pl.startswith("plugin://"):
        return True

    if _is_lan_or_local_playback(pl):
        return False

    return True


def _ping_via_iface(ifname, host, timeout_sec):
    """
    Low-cost connectivity check via a specific interface (HARDENED).
    Uses subprocess.run with proper cleanup.
    Returns True on success.
    """
    try:
        t = int(timeout_sec)
        if t < 1:
            t = 1
    except Exception:
        t = 1

    # Input validation
    try:
        ifname_str = str(ifname).strip()
        host_str = str(host).strip()
        
        # Basic validation to prevent command injection
        if not ifname_str or not host_str:
            return False
        if len(ifname_str) > 16 or len(host_str) > 253:
            return False
        if any(c in ifname_str for c in [';', '|', '&', '$', '`', '\n', '\r']):
            return False
        if any(c in host_str for c in [';', '|', '&', '$', '`', '\n', '\r']):
            return False
            
    except Exception:
        return False

    cmd = ["ping", "-4", "-n", "-c", "1", "-I", ifname_str, "-W", str(t), host_str]
    
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=float(t) + 2.0,
            check=False
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False
    except Exception:
        return False


def run():
    _log("service starting v1.5.0 (IPv4-only, Quad9 privacy, NTP firewall protection, Full IP anonymization, IPv6 blocking)")
    
    # ===== OLD NTP SERVICE DISABLING CODE (DEPRECATED) =====
    # Now using firewall-based NTP protection instead (ntp_firewall=True in enforcer)
    # Keeping this code commented out in case someone wants to revert
    # 
    # try:
    #     _disable_ntp_services()
    # except Exception as e:
    #     _log(f"Failed to disable NTP services: {e}")
    #     _log("Continuing with VPN protection (NTP leaks may still occur)")
    # =======================================================

    enf = WgEnforcer(
        wireguard_dir="/storage/.config/wireguard",
        wan_if="eth0",
        check_sec=2,
        handshake_max_age_sec=0,      # keep unchanged
        dns_firewall=True,
        ntp_firewall=True,
        dns_chain=_dns_chain_for_addon(_ADDON_ID),
        dns_status_log_sec=60,
        anonymize_all_ips=True,
    )
    
    _log("Full IP anonymization enabled - all IPs hashed in logs")
    _log("IPv6 blocking enabled - defense-in-depth protection")

    monitor = xbmc.Monitor()
    player = xbmc.Player()
    dialog = xbmcgui.Dialog()

    # Grace periods / throttles (unchanged)
    boot_grace_sec = 10
    reconnect_grace_sec = 6
    vpn_down_persist_sec = 6
    kill_cooldown_sec = 10.0

    # Notification rate limiting (unchanged)
    notification_cooldown_sec = 30.0
    last_notification_ts = 0.0

    start_ts = time.time()
    last_vpn_ok_ts = 0.0
    last_kill_ts = 0.0
    vpn_down_since = 0.0

    # State tracking for debugging (unchanged)
    last_vpn_state = None
    state_change_count = 0

    # Dead-tunnel detection (PRIVACY: 1.1.1.1 -> 9.9.9.9 Quad9)
    wg_ping_host = "9.9.9.9"  # Quad9 DNS for privacy
    wg_ping_interval_sec = 30.0
    wg_ping_interval_idle_sec = 60.0  # Reduced frequency when idle
    wg_ping_timeout_sec = 2
    wg_ping_fail_needed = 2
    wg_reconnect_cooldown_sec = 20.0

    last_wg_ping_ts = 0.0
    wg_ping_fail_count = 0
    last_wg_reconnect_ts = 0.0

    # Small grace period for connman on boot
    for _ in range(10):
        if monitor.abortRequested():
            _log("abort during early wait")
            return
        monitor.waitForAbort(0.5)

    while not monitor.abortRequested():
        status = None
        try:
            status = enf.tick()
        except Exception as e:
            _log("tick error: %s" % e)

        try:
            vpn_ok = False
            reason = "unknown"
            wgif = None

            if isinstance(status, dict):
                vpn_ok = bool(status.get("vpn_ok"))
                reason = status.get("reason", "unknown")
                wgif = status.get("wg")
            else:
                vpn_ok, wgif, reason = enf.vpn_ok()

            now = time.time()

            # Dead-tunnel check:
            # If enforcer says VPN is OK, but wg can't reach a known public IP, treat as down and reconnect.
            if vpn_ok and wgif:
                # Use longer interval when system is idle (not playing)
                ping_interval = wg_ping_interval_idle_sec if not player.isPlaying() else wg_ping_interval_sec
                
                if (now - last_wg_ping_ts) >= ping_interval:
                    last_wg_ping_ts = now
                    if _ping_via_iface(wgif, wg_ping_host, wg_ping_timeout_sec):
                        wg_ping_fail_count = 0
                    else:
                        wg_ping_fail_count += 1
                        _log("WG ping fail %d/%d iface=%s host=%s" % (
                            wg_ping_fail_count, wg_ping_fail_needed, str(wgif), str(wg_ping_host)
                        ))

                        if wg_ping_fail_count >= wg_ping_fail_needed:
                            wg_ping_fail_count = 0
                            vpn_ok = False
                            reason = "wg_ping_fail"

                            if (now - last_wg_reconnect_ts) >= wg_reconnect_cooldown_sec:
                                last_wg_reconnect_ts = now
                                _log("Dead tunnel suspected -> connman reconnect")
                                try:
                                    # Use enforcer's reconnect helper (same logic as tick())
                                    enf._connect_all_vpns()
                                except Exception:
                                    pass

            # Log vpn state changes (unchanged behavior, just uses final vpn_ok after dead-tunnel logic)
            if last_vpn_state is None:
                last_vpn_state = vpn_ok
                state_change_count = 0
            elif last_vpn_state != vpn_ok:
                last_vpn_state = vpn_ok
                state_change_count += 1
                _log("VPN state change #%d: %s (%s)" % (state_change_count, str(vpn_ok), str(reason)))

            if vpn_ok:
                last_vpn_ok_ts = now
                vpn_down_since = 0.0
            else:
                if vpn_down_since <= 0.0:
                    vpn_down_since = now

            # Kill-switch: only if playing and should kill, AND out of grace windows
            if player.isPlaying() and _should_kill_when_vpn_down(player):
                if not vpn_ok:
                    # boot grace
                    if (now - start_ts) < boot_grace_sec:
                        pass
                    # reconnect grace after last ok
                    elif last_vpn_ok_ts and (now - last_vpn_ok_ts) < reconnect_grace_sec:
                        pass
                    # must persist
                    elif vpn_down_since and (now - vpn_down_since) < vpn_down_persist_sec:
                        pass
                    else:
                        if (now - last_kill_ts) >= kill_cooldown_sec:
                            last_kill_ts = now
                            _log("KILL playback (vpn not ok: %s)" % reason)

                            # notification cooldown
                            if (now - last_notification_ts) >= notification_cooldown_sec:
                                last_notification_ts = now
                                try:
                                    dialog.notification(
                                        "Kronos Cave",
                                        "VPN down - stopping stream",
                                        xbmcgui.NOTIFICATION_ERROR,
                                        2500
                                    )
                                except Exception:
                                    pass

                            try:
                                player.stop()
                            except Exception:
                                pass
        except Exception as e:
            _log("killswitch error: %s" % e)

        monitor.waitForAbort(float(getattr(enf, "check_sec", 2)))

    # Shutdown cleanup
    try:
        enf.cleanup()
    except Exception:
        pass

    _log("service stopping")


if __name__ == "__main__":
    run()