# -*- coding: utf-8 -*-
# Kronos Oculus / Eye — occult_stuff_shh
# v1.3.2 (Kodi 21 Omega, LibreELEC-safe)
# - Fixed: Saturn now only notifies for the most recent ingress
# - Startup grace: 24 seconds before first check
# - Persistent loop: checks every 6 hours
# - All date calculations in UTC

import os
import sys
import datetime
import json
import xbmc
import xbmcvfs

# ===== Config / Constants =====
ADDON_ID = 'service.kronos.eye'
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}')
ADDON_DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
DATA_FILE = os.path.join(ADDON_DATA_PATH, 'saturn_moon_status.json')

# Saturn ingress dates (placeholders – replace with real ephemeris later)
# Format: "YYYY-MM-DD": "Zodiac"
SATURN_INGRESS = {
    "2023-03-07": "Pisces",
    "2025-05-24": "Aries",
    "2028-04-12": "Taurus",
    "2030-08-01": "Gemini",
    "2033-10-19": "Cancer",
    "2035-12-06": "Leo",
    "2038-02-22": "Virgo",
    "2040-05-10": "Libra",
    "2043-07-29": "Scorpio",
    "2045-10-15": "Sagittarius",
    "2048-01-01": "Capricorn",
    "2050-03-20": "Aquarius",
    "2053-06-07": "Pisces",
    "2055-08-25": "Aries",
    "2058-11-11": "Taurus"
}

# ===== Monitor for abort handling =====
monitor = xbmc.Monitor()

# ===== I/O helpers =====
def ensure_dirs():
    """Create data directory if it doesn't exist"""
    try:
        if not os.path.exists(ADDON_DATA_PATH):
            os.makedirs(ADDON_DATA_PATH)
            xbmc.log(f"[Kronos Eye] Created data dir: {ADDON_DATA_PATH}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Kronos Eye] Failed to create data dir: {e}", xbmc.LOGERROR)

def load_status():
    """Load saved notification status"""
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as f:
                data = json.load(f)
                return data
    except Exception as e:
        xbmc.log(f"[Kronos Eye] Load status error: {e}", xbmc.LOGINFO)
    return {}

def save_status(data):
    """Save notification status"""
    try:
        ensure_dirs()
        with open(DATA_FILE, 'w') as f:
            json.dump(data, f, indent=2)
            f.flush()
        xbmc.log("[Kronos Eye] Status saved", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Kronos Eye] Save error: {e}", xbmc.LOGERROR)

# ===== Notification =====
def show_notification(title, message, icon_file, time=10000):
    """
    Show Kodi notification using reliable icon path
    """
    try:
        # Build icon path using the add-on's install location
        icon_path = os.path.join(ADDON_PATH, 'resources', 'media', icon_file)
        
        # Verify icon exists, fallback to add-on default icon
        if not os.path.exists(icon_path):
            icon_path = os.path.join(ADDON_PATH, 'icon.png')
            if not os.path.exists(icon_path):
                icon_path = ''  # Let Kodi use its own default
        
        # Execute notification
        cmd = f'Notification("{title}","{message}",{time},"{icon_path}")'
        xbmc.executebuiltin(cmd)
        xbmc.log(f"[Kronos Eye] Notification sent: {title}", xbmc.LOGINFO)
        
    except Exception as e:
        xbmc.log(f"[Kronos Eye] Notification error: {e}", xbmc.LOGERROR)

# ===== Moon Phase Calculation =====
def is_full_moon(date_obj):
    """
    Calculate if today is a full moon using UTC date
    """
    try:
        # Known full moon reference (Jan 6, 2000 was a full moon)
        known_full = datetime.date(2000, 1, 6)
        lunar_cycle = 29.53058867  # Synodic month in days
        
        days_passed = (date_obj - known_full).days
        moon_age = days_passed % lunar_cycle
        
        # Full moon window (±0.5 days)
        is_full = 14.27 <= moon_age <= 15.27
        
        xbmc.log(f"[Kronos Eye] Moon age: {moon_age:.2f} days -> full={is_full}", xbmc.LOGINFO)
        return is_full
        
    except Exception as e:
        xbmc.log(f"[Kronos Eye] Moon calculation error: {e}", xbmc.LOGERROR)
        return False

# ===== Main Service =====
def main():
    """Main service entry point with persistent loop"""
    xbmc.log("[Kronos Eye] v1.3.2 starting", xbmc.LOGINFO)
    
    try:
        # Wait for Kodi to fully start (24 seconds grace, abort-safe)
        xbmc.log("[Kronos Eye] Waiting 24 seconds for Kodi to settle...", xbmc.LOGINFO)
        if monitor.waitForAbort(24):
            xbmc.log("[Kronos Eye] Abort requested during startup", xbmc.LOGINFO)
            return
        
        # Main service loop – runs every 6 hours
        while not monitor.abortRequested():
            try:
                # Load previous state
                status = load_status()
                
                # Get current UTC date
                now_utc = datetime.datetime.utcnow()
                today_utc = now_utc.date()
                
                updated = False
                
                # ===== Full Moon Check =====
                try:
                    last_full = status.get('last_fullmoon')
                    
                    if last_full != str(today_utc):
                        if is_full_moon(today_utc):
                            show_notification(
                                "Kronos Eye",
                                "Step into the light",
                                "fullmoon.png",
                                8000
                            )
                            status['last_fullmoon'] = str(today_utc)
                            updated = True
                            xbmc.log("[Kronos Eye] Full moon notification sent", xbmc.LOGINFO)
                    else:
                        xbmc.log("[Kronos Eye] Full moon already notified today", xbmc.LOGINFO)
                        
                except Exception as e:
                    xbmc.log(f"[Kronos Eye] Full moon error: {e}", xbmc.LOGERROR)
                
                # ===== Saturn Ingress Check =====
                try:
                    # Find the most recent ingress date <= today
                    latest_ingress_date = None
                    latest_zodiac = None
                    
                    for date_str, zodiac in SATURN_INGRESS.items():
                        ingress_date = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
                        if ingress_date <= today_utc:
                            if latest_ingress_date is None or ingress_date > latest_ingress_date:
                                latest_ingress_date = ingress_date
                                latest_zodiac = zodiac
                    
                    if latest_ingress_date:
                        latest_year = latest_ingress_date.year
                        last_saturn_year = status.get('last_saturn_year')
                        
                        if last_saturn_year != latest_year:
                            show_notification(
                                "Kronos Eye",
                                f"Saturn has entered {latest_zodiac}",
                                "saturn.png",
                                8000
                            )
                            status['last_saturn_year'] = latest_year
                            updated = True
                            xbmc.log(f"[Kronos Eye] Saturn ingress: {latest_zodiac} (date {latest_ingress_date})", xbmc.LOGINFO)
                        else:
                            xbmc.log("[Kronos Eye] Saturn already notified for the current ingress", xbmc.LOGINFO)
                    else:
                        xbmc.log("[Kronos Eye] No Saturn ingress has occurred yet", xbmc.LOGINFO)
                        
                except Exception as e:
                    xbmc.log(f"[Kronos Eye] Saturn error: {e}", xbmc.LOGERROR)
                
                # Always write a timestamp to prove the service is running
                status['_last_check'] = datetime.datetime.utcnow().isoformat()
                updated = True  # force save
                
                # Save updated state
                if updated:
                    save_status(status)
                else:
                    xbmc.log("[Kronos Eye] No updates needed", xbmc.LOGINFO)
                
                # Wait 6 hours before next check (abort-safe)
                xbmc.log("[Kronos Eye] Next check in 6 hours", xbmc.LOGINFO)
                if monitor.waitForAbort(21600):  # 6 hours = 21600 seconds
                    xbmc.log("[Kronos Eye] Abort requested during wait", xbmc.LOGINFO)
                    break
                    
            except Exception as e:
                xbmc.log(f"[Kronos Eye] Loop iteration error: {e}", xbmc.LOGERROR)
                # Brief pause before retrying to avoid tight error loop
                if monitor.waitForAbort(60):
                    break
        
    except SystemExit:
        xbmc.log("[Kronos Eye] Service stopped by abort", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Kronos Eye] Critical error: {e}", xbmc.LOGERROR)
    
    xbmc.log("[Kronos Eye] v1.3.2 finished", xbmc.LOGINFO)

if __name__ == '__main__':
    main()